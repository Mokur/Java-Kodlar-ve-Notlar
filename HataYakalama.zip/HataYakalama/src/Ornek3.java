
public class Ornek3 {

	public static void main(String[] args) {
		// stringin olmayan de�erine eri�meye �al��mak
		
		String isim = "�SMEK";
		

		
		try {
			System.out.println(isim.charAt(5));
		}catch(StringIndexOutOfBoundsException e) {
			System.out.println("Stringin olmayan bir de�erine ula�maya �al��t�n�z");
			System.out.println(e.getMessage());
			
		}
	}

}
