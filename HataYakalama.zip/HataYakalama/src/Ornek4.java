
public class Ornek4 {

	public static void main(String[] args) {
		// ArrayIndexOutOfBoundsException: dizilerde al�nan hata, yanl�� indise ula�maya �al��mak

		String[] dizi = {"ismek","bili�im","okulu"};

		
		try {
			System.out.println(dizi[3]);
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Dizinin olmayan indisine eri�meye �al��t�n�z!");
		}
	}

}
