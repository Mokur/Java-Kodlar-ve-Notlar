
public class Ornek6 {

	public static void main(String[] args) {
		// NumberFormatException: stringleri integera �eviremezsin, say� string olarak yaz�lm��sa d�n���m yap�labilir

		String s = "a";

		
		
		
		try {
			int sayi = Integer.parseInt(s);
			System.out.println(sayi);
		}catch(NumberFormatException e) {
			System.out.println("Stringi int'e �evirirken hata olu�tu!");
		}
		
	}

}
