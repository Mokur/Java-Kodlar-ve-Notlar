import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		// Aritmethic exception : bir say�y� s�f�ra b�lme hatas�
		
		//iki say� ikinci 0, sonu� birinciyi 0a b�l 
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Bir say� giriniz:");
		int sayi = sc.nextInt();
		
		System.out.println("�kinci say�y� giriniz:");
		int sayi2 = sc.nextInt();
		


		
		try{
			System.out.println("Birinci say�n�n ikinci say�ya b�l�m�: " +(sayi/sayi2));
		}catch(ArithmeticException e) {
			//s�f�ra b�lme hatas�
			System.out.println("S�f�ra b�lme hatas�");
			System.out.println(e.getMessage());//hata mesaj�
			e.printStackTrace();//hatay� d�nd�r�r
		}
	}

}
