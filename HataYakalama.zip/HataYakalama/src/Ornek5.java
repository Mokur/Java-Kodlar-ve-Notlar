
public class Ornek5 {

	public static void main(String[] args) {
		// NullPointerException : bo� de�er hatas�

		String yazi = null;
		
		
		
		try {
			yazi.charAt(0);

		}catch(NullPointerException e) {
			System.out.println("Yaz� de�i�keni tan�ms�zd�r. De�er atamas� yap�lmadan eri�ilemez");
		}
		
	}

}
