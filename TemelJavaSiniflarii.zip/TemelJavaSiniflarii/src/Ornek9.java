import java.util.Scanner;

public class Ornek9 {

	public static void main(String[] args) {
		// girilen stringtteki a'lar� yazd�rma
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Bir kelime giriniz: ");
		String kelime = sc.next();
		
		
		for (int i = 0; i < kelime.length(); i++) {
			if(kelime.charAt(i)!='a') {
				System.out.print(kelime.charAt(i));
			}
		}

	}

}
