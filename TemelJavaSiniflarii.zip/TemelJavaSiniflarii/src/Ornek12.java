
public class Ornek12 {

	public static void sirala(int[] dizi, char ch) {
		//int[] dizi = {5,70,9,140,3,74,0};
		
		int gecici;
		//t�m elemanlar� tek tek gezebilmek i�in �rettik
		for (int i = 0; i < dizi.length; i++) {
			//bir �nceki de�erle bir sonraki de�eri her zaman k�yaslayabilmek i�in
			for (int j = i+1; j < dizi.length; j++) {
				if('>' == ch) {
					if(dizi[i]>dizi[j]) {
						gecici = dizi[i];
						dizi[i] = dizi[j];
						dizi[j] = gecici;
					}
				}else if('<' == ch) {
					if(dizi[i]<dizi[j]) {
						gecici = dizi[i];
						dizi[i] = dizi[j];
						dizi[j] = gecici;
					}
				}
			}
		}
		
		for (int i = 0; i < dizi.length; i++) {
			System.out.print(dizi[i]+" ");
		}
	}

	public static void main(String[] args) {
		// K���kten b�y��e s�ralama (Sorting Selection Algorithm)
		
		// 0 5 70 9 14 7
		// 0 5 7 9 14 70
		
		int[] dizi = {5,70,9,140,3,74,0};
		sirala(dizi, '>');
		System.out.println("\n");
		sirala(dizi, '<');
		
		
		
	}
}
