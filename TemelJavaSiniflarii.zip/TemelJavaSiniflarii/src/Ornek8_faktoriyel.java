import java.util.Scanner;

public class Ornek8_faktoriyel {

	public static void main(String[] args) {
		// for ve while ile fakt�riyel hesaplamas�

		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Fakt�riyeli al�nacak say�y� girin: ");
		int sayi = sc.nextInt();
		
		//while ile
		int fakt = 1;
		while(sayi>1) {
			fakt *= sayi;
			sayi--;
		}
		System.out.println("Fakt�riyel: "+fakt);
		
		/*
		 * for ile:
		 * int fak = 1;
		for (int i = sayi; i > 1; i--) {
			fak *= i; 
		}
		
		System.out.println("Fakt�riyel: "+fak);
		
		 */
		
		
		
		
		
		
	}

}
