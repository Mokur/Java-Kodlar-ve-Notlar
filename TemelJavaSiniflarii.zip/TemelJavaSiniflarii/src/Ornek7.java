import java.util.Random;

public class Ornek7 {

	public static void main(String[] args) {
		/*
		 * 10 elemanl� bir int dizisi olu�tur. de�erleri random s��n�f� ile al random
		 * s�n�f� ile ald���n de�erleri diziye at�p tek olanlar� ve �ift olanlar� ayr�
		 * ayr� d�ng�lerle yazd�r
		 */

		Random rastgele = new Random();

		int[] dizi = new int[10];

		for (int i = 0; i < 10; i++) {
			int sayi = rastgele.nextInt(50);
			dizi[i] = sayi;
		}

		System.out.println("�iftler: ");
		for (int i : dizi) {
			if (i % 2 == 0) {
				System.out.println(i);
			}

		}

		System.out.println("Tekler: ");
		for (int i : dizi) {
			if (i % 2 == 1) {
				System.out.println(i);
			}
		}
	}

}
