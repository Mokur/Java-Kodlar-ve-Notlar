import java.util.Scanner;

public class Ornek10 {
	
	
	public static int unlulerinSayisiniBul(String kelime) {
		
	
		
			String unluDizi[] = { "a", "e", "�", "i", "o", "�", "u", "�" };
			int sayac = 0;
			for (int i = 0; i < kelime.length(); i++) {
				for (int j = 0; j < unluDizi.length; j++) {
					if (kelime.charAt(i) == unluDizi[j].charAt(0)) {
						sayac++;
					}
				}

			}
			return sayac;
		
	}
	
	
	
	public static int sayilarinSayisiniBul(String kelime) {
		String sayilar= "0123456789";
		
		int sayac=0;
		
		for (int i = 0; i < kelime.length(); i++) {
			for (int j = 0; j < sayilar.length(); j++) {
				if (kelime.charAt(i)==sayilar.charAt(j)) {
					sayac++;
				}
			}
		}
		return sayac;
	}
	
	
	
	
	

	public static void main(String[] args) {
		// d��ar�dan kelime, kelimedeki �nl� harf say�s�kontrol et

		Scanner sc = new Scanner(System.in);

		System.out.println("Bir kelime giriniz: ");
		String kelime = sc.next();
		
		unlulerinSayisiniBul(kelime);
		
		

		
		
		//daha k�sa yolu
		/*
		 * String unluler = "ae�io�u�";
		stringin direk charAt metodunu kullan�rs�n
		 * 
		 */
		

	}

}
