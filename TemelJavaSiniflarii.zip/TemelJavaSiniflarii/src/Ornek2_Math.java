
public class Ornek2_Math {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double pi = Math.PI; //static s�n�f oldu�u i�in b�yle geliyor
		System.out.println("PI say�s�: "+pi);
		
		double e = Math.E;
		System.out.println("EULER say�s�: "+e);
		
		double min = Math.min(10, 90);
		System.out.println("En k���k say�: "+min);
		
		double max = Math.max(50, 140);
		System.out.println("En b�y�k say�: "+max);
		
		double ceil = Math.ceil(1540.72);
		//k�s�rattan sonraki k�sm� dikkate almaz, say�y� 1 �ste yuvarlar
		System.out.println(ceil);
		
		
		//0-1 aras� rastgele say� �retir
		double rastgeleSayi = Math.random();
		System.out.println(rastgeleSayi);
		
		
		//k�s�rat olan k�sm� s�f�ra indirir
		double floor = Math.floor(150.43);
		System.out.println(floor);
		
		double mutlakDeger = Math.abs(50.7);
		System.out.println("Mutlak De�er: "+mutlakDeger);
		
		double kareKok = Math.sqrt(10.8);
		System.out.println("Karek�k: "+kareKok);
		
		
		//0.50 �ncesini alt say�ya , 0.50 sonras�n� �st say�ya yuvarlar.
		double round = Math.round(45.2);
		System.out.println("Round ile yuvarlama: "+round);
		

	}

}
