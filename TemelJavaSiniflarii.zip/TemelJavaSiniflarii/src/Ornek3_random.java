import java.util.Random;

public class Ornek3_random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Random rastgele = new Random();
		
		int sayi = rastgele.nextInt();
		System.out.println(sayi);
		
		int sayi2 = rastgele.nextInt();
		System.out.println(sayi2);
		
		int sayi3 = rastgele.nextInt(5);
		System.out.println(sayi3);
	}

}
