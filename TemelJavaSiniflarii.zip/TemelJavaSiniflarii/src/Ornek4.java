import java.util.Random;

public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Random rastgele = new Random();
		
		int sayi = rastgele.nextInt(10);
		System.out.println("�lk sayi: "+sayi);
		
		int sayi2 = rastgele.nextInt(10);
		System.out.println("�kinci sayi: "+sayi2);
		
		double min = Math.min(sayi, sayi2);
		double max = Math.max(sayi, sayi2);
		
		if(sayi<sayi2) {
			System.out.println("�lk say� k���kt�r: " +sayi);
		}else if(sayi2<sayi) {
			System.out.println("�kinci say� k���kt�r: "+sayi2);
		}
	}

}
