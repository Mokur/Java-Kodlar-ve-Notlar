import java.util.Random;
import java.util.Scanner;

public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//say� tahmin oyunu
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("0-5 aras� bir say� girin: ");
		int tahmin = sc.nextInt();
		
		Random rastgele = new Random();
		
		int sayi = rastgele.nextInt(5);
		
		
		
		if(tahmin==sayi) {
			System.out.println("Do�ru Cevap!");
		}else if(tahmin < sayi) {
			System.out.println("Daha b�y�k bir say� deneyin!");
		}else {
			System.out.println("Daha k���k bir say� deneyin!");
		}
	}

}
