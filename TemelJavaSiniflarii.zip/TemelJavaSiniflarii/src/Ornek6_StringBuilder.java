
public class Ornek6_StringBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String ad = "�erif";
		String soyad = "g�ng�r";
		
		System.out.println(ad+soyad);
		
		StringBuilder sb = new StringBuilder();
		sb.append("�erif");
		sb.append(5);
		sb.append(true);
		sb.append(5.7);
		sb.append('c');
		
		System.out.println(sb.toString());


	}

}
