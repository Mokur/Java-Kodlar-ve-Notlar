
public class Ornek11 {

	public static int unlulerinSayisiniBul(String metin) {
		String unluler = "ae�io�u�";
		metin = metin.toLowerCase();
		int sayac =0;
		//T�m karakterleri gezmek i�in
		for (int i = 0; i < metin.length(); i++) {
			//�lgili karakterin unlulerin ilgili karakteri ile k�yas etmek i�in
			for (int j = 0; j < unluler.length(); j++) {
				if(metin.charAt(i)==unluler.charAt(j)) {
					sayac++;
				}
			}
		}
		return sayac;
	}
	
	public static int sayilarinSayisiniBul(String metin) {
		String sayilar = "0123456789";
		int sayac = 0;
		for (int i = 0; i <metin.length(); i++) {
			for (int j = 0; j < sayilar.length(); j++) {
				if(metin.charAt(i)==sayilar.charAt(j)) {
					sayac++;
				}
			}
		}
		return sayac;
	}
	
	public static int unsuzlerinSayisiniBul(String metin) {
		metin = metin.toLowerCase();
		String unsuzler = "qwrtyp�sdfghjkl�zxcvbnm�";
		int sayac = 0;
		for (int i = 0; i <metin.length(); i++) {
			for (int j = 0; j < unsuzler.length(); j++) {
				if(metin.charAt(i)==unsuzler.charAt(j)) {
					sayac++;
				}
			}
		}
		return sayac;
	}


	public static void main(String[] args) {
		
		String metin = "java - 1";
		
		
		int metninUzunlugu = metin.length();
		int sayiAdedi = sayilarinSayisiniBul(metin);
		int unlulerinSayisi = unlulerinSayisiniBul(metin);
		int unsuzlerinSayisi = unsuzlerinSayisiniBul(metin);
		
		System.out.println("Metin: "+metin);
		System.out.println("Say�lar�n adedi: "+sayiAdedi);
		System.out.println("�nl� harf say�s�: "+unlulerinSayisi);
		System.out.println("�ns�z harf say�s�: "+unsuzlerinSayisi);
		int toplam = sayiAdedi+unlulerinSayisi+unsuzlerinSayisi;
		
		if(toplam!=metninUzunlugu) {
			int ozelKarakterSayisi = metninUzunlugu-toplam;
			System.out.println("�zel Karakter say�s�: "+ozelKarakterSayisi);
		}
		
	}

}


