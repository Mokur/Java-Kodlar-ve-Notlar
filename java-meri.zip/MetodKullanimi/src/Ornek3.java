
public class Ornek3 {

	
	public static String buyukKucukYaz(String str) {
		String s = "";
		for (int i = 0; i < str.length(); i++) {
			if (i%2==0) {
				s += Character.toLowerCase(str.charAt(i));
				
			}else {
				s += Character.toUpperCase(str.charAt(i));
			}
		}
		return s;
	}
	
	public static void main(String[] args) {
		//d��ar�dan bir kelime girip, tek karakterlerini b�y�k, �ift karakterlerini b�y�k

		String sonuc = buyukKucukYaz("MERHABA D�NYA");
		System.out.println(sonuc);
		
	}

}
