import java.util.Scanner;

public class Ornek2 {

	//iki say� aras�ndaki say�lar� listele
	
	
	public static void listele() {
		Scanner sc = new Scanner(System.in);
		System.out.println("ilk sayiyi girin:");
		int sayi1= sc.nextInt();
		
		System.out.println("�kinci sayiyi girin:");
		int sayi2= sc.nextInt();
		
	
		for (int i = sayi1; i <= sayi2; i++) {
			System.out.println(i);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		listele();

	}

}
