import java.util.Scanner;

public class Ornek1 {
	
	
	public int cikar(int sayi1, int sayi2) {
		
		int fark = sayi1 - sayi2;
		return fark;
		
	}
	
	
	public int carp(int sayi1, int sayi2) {
		
		int carpim = sayi1 * sayi2;
		return carpim;
		
	}
	
	
	public int bol(int sayi1, int sayi2) {
		
		int bolum = sayi1 / sayi2;
		return bolum;
		
	}
	
	
	
	public void selamVer() {
		System.out.println("herkese selamlar");
	}
	
	public int topla(int sayi1, int sayi2) {
		
		int toplam = sayi1 + sayi2;
		return toplam;
		
	}

	public static void main(String[] args) {
		// DI�ARIDAN  GER� D�N�� T�P� VO�D OLAN B� METOD �RET, 

		//static yapmazsak class�m�zda bir nesne �retip, o nesneden metodlar� �a��rabiliyoruz.
		Ornek1 o = new Ornek1();//nesne �rettik
		o.topla(1, 2);//nesnenin metodunu �a��rd�k
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("�lk say�y� girin:");
		int sayi1 = sc.nextInt();
		
		
		System.out.println("�kinci say�y� girin:");
		int sayi2 = sc.nextInt();
	
		
		System.out.println("��lemi se�in(topla  cikar  bol  carp):");
		String islem = sc.next();
		
		
		
		if("topla".equals(islem)) {
			
			int sonuc = o.topla(sayi1,sayi2);
			System.out.println("Toplam: " +sonuc);
		}else if("cikar".equals(islem)) {
			int sonuc = o.cikar(sayi1,sayi2);
			System.out.println("Fark: " +sonuc);
		}else if("bol".equals(islem)) {
			int sonuc = o.bol(sayi1,sayi2);
			System.out.println("B�l�m: " +sonuc);
		}else if("carp".equals(islem)) {
			int sonuc = o.carp(sayi1,sayi2);
			System.out.println("�arp�m: " +sonuc);
		}else {
			System.out.println("Hata!");
		}
		
		
	}

}
