import java.io.File;

public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		File f = new File("D:/JAVA_DOSYA/ders");
		
		f.mkdir(); // dizin-klas�r �retir
		
		if(f.isDirectory()) {
			System.out.println("ders bir klas�rd�r");
		}else if(f.isFile()) {
			System.out.println("ders bir dosyad�r");
		}else if(f.isHidden()) {
			System.out.println("ders gizlenmi�tir");
		}else if(f.isAbsolute()) {
			System.out.println("ders is a absolute");
		}
		
	}

}
