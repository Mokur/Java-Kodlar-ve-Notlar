import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ornek9 {

	
	private static boolean dosyayaEkle(String konum, String yazi) {
		boolean b = false;
		try {
			File dosya = new File(konum);
			FileWriter yazici = new FileWriter(dosya,true);
			BufferedWriter yaz = new BufferedWriter(yazici);
			yaz.write(yazi);
			yaz.close();
			b = true;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return b;
	}
	public static void main(String[] args) {
		// Td��ar�dan girilen metni dosyaya yazd�r
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Bir metin giriniz:");
		String metin = sc.nextLine();
		
		String konum = "D:/metin.txt";
		File f = new File(konum);
		
		if(f.exists()) {//dosya vard�r
			//yazmaya ba�la
			boolean b = dosyayaEkle("D:/JAVA_DOSYA/metin.txt",metin);
			if(b) {
				System.out.println("Dosyaya yaz�ld�");
				
			}else {
				System.out.println("Dosyaya yaz�lmad�");

			}
			

		}else {
			//olu�tur sonra yaz
			
			try {
				f.createNewFile();
			}catch(IOException e) {
				e.printStackTrace();
			}
			
	
			boolean b = dosyayaEkle("D:/JAVA_DOSYA/metin.txt",metin);
			if(b) {
				System.out.println("Dosyaya yaz�ld�");
				
			}else {
				System.out.println("Dosyaya yaz�lmad�");

			}
		}
		
		
		
		
		
		
		
		

	}

}
