import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Ornek8 {

	private static boolean dosyayaEkle(String konum, String yazi) {
		boolean b = false;
		try {
			File dosya = new File(konum);
			FileWriter yazici = new FileWriter(dosya,true);
			BufferedWriter yaz = new BufferedWriter(yazici);
			yaz.write(yazi);
			yaz.close();
			b = true;
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return b;
	}
	
	
	public static void main(String[] args) {
		// dosyaya yazma i�lemi
		
		String konum = "D:/javase.txt";
		File f = new File(konum);
		
		if(f.exists()) {//dosya vard�r
			//yazmaya ba�la
			dosyayaEkle(konum,"Merhaba");
			dosyayaEkle(konum," Ben");
			dosyayaEkle(konum," Meri");

		}else {
			//olu�tur sonra yaz
			
			try {
				f.createNewFile();
			}catch(IOException e) {
				e.printStackTrace();
			}
			dosyayaEkle(konum,"Merhaba");
			dosyayaEkle(konum,"Ben");
			dosyayaEkle(konum,"Meri");
			
		}

	}

}
