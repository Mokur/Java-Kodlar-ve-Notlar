import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Ornek10 {
	
	//fileOutputStream ile dosyaya yazma i�lemini ara�t�r
	
	//dosyay� okuyup yazd�rd�k
	
	public static String dosyayiOku(String konum) {
		String str = "";
		File f = new File(konum);
		FileInputStream fis;
		
		try {
			fis = new FileInputStream(f);
			int ch = 0;
			
			try {
				while((ch=fis.read())!=-1) {
					str += (char)ch;
			}
			}catch (IOException e) {
				
				e.printStackTrace();
			}
			
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
			System.out.println(dosyayiOku("D:/JAVA_DOSYA/metin.txt"));
		
		
	}

}
