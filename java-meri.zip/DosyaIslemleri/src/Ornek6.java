import java.io.File;

public class Ornek6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f = new File("D:/deneme");
		
		if(f.exists()) {
			System.out.println("D:/deneme konumu vard�r");
		}else {
			System.out.println("D:/deneme konumu yoktur");
		}
		
	}

}
