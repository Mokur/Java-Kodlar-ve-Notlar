import java.io.File;

public class Ornek7 {
	
	public static void dosyaIsimleriniListele(String konum, String uzanti) {
		
		File f = new File(konum);
		String[] dosyaIsimleri = f.list();
		for (int i = 0; i < dosyaIsimleri.length; i++) {
			if(dosyaIsimleri[i].endsWith(uzanti)) {
				System.out.println(dosyaIsimleri[i]);
			}
			
		}
	}

	public static void main(String[] args) {
		// Bir lokasyondaki t�m dosya ve klas�r isimlerini listelemek
		
		
		dosyaIsimleriniListele("C:/",".sys");
		
		
		

	}

}
