import java.io.File;
import java.io.IOException;

public class Ornek3 {

	public static void main(String[] args) {
		//10 tane dosya olu�tur

		File dosya = null;
		
		
		for (int i = 1; i > 10; i++) {
			dosya = new File("D:/JAVA_DOSYA/dosya_"+i+".txt");
			try {
				boolean b = dosya.createNewFile();
				
				if(b) {
					System.out.println("dosya_"+i+".txt �retildi");
				}else {
					System.out.println("dosya_"+i+".txt �retilmedi");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
