import java.io.File;
import java.io.IOException;

public class Ornek1 {
	
	
	public void deneme() throws IOException {
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		File dosya = new File("D:/JAVA_DOSYA/javaprogramlama_1.txt"); // �al��mak istedi�in lokasyonu belirtmek i�in kullan�l�r �ift t�rnak i�indeki yer
		
	
		//B�R DOSYA �RETMEK
		try {
			
			boolean sonuc = dosya.createNewFile();
			if(sonuc) {
				System.out.println("Dosya olu�turuldu!");
			}else {
				System.out.println("Dosya olu�turulamad�!");
			}
			//javaprogramlama_1.txt 'yi bu kod �retir, yukardaki konumu belirtir
			//try catch blo�uyla kullanman gerekiyor
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
		
		
	}

}
