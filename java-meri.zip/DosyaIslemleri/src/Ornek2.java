import java.io.File;
import java.io.IOException;

public class Ornek2 {

	
	public void deneme() throws IOException {
		
		
	} 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		File dosya = new File("D:/JAVA_DOSYA/javaprogramlama_1.txt");
		
		
		boolean b = dosya.delete();
		
		if(b) {
			System.out.println("Dosya silindi");
		}else {
			
			System.out.println("Dosya silinmedi");
		}
	}

}
