
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.Duration;
import java.time.LocalTime;
import java.util.Scanner;




public class Database_deneme {

	public static int saatFarkiniHesapla(Date time1,Date time2) {
		int saatFarki = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	    LocalTime t1 = LocalTime.parse(sdf.format(time1));
	    LocalTime t2 = LocalTime.parse(sdf.format(time2));
	    Duration diff = Duration.between(t2, t1);
	    saatFarki = (int)diff.toHours();
	    return saatFarki;
}
	
	
	
	static Scanner sc;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sc = new Scanner(System.in);
		Database db = new Database();
		db.baglan("otopark", "root", "", "127.0.0.1", 3306);
		int sayi = db.tablodakiVeriSayisi("ucretler");
		//System.out.println(sayi);
		
		
		while (true) {
			System.out.println("L�tfen bir i�lem se�iniz:");
			System.out.println("1 - �cret Tarifelerini Listele");
			System.out.println("2 - Otopark Yerlerini Listele");
			System.out.println("3 - Bir Otoparka Ara� Giri�i Yap");
			System.out.println("4 - Bir Otoparktan Ara� ��k��� Yap");
			System.out.println("5 - Kasadaki Kazanc� G�r");
			System.out.println("6 - Otoparktaki Ara�lar� Listele");
			System.out.println("7 - Otoparktaki Ara� Say�s�n� ��ren");
			System.out.println("8 - Otoparktan ��kan Ara�lar� Listele");


			int islemSayi = sc.nextInt();
			
			
			if (islemSayi==1) {
				
				
				/*
				 ResultSet s�n�f� sayesinde select sorgusundan d�nen t�m sat�r sonu�lar�n� listeleyebiliriz
				 */
				
				ResultSet rs = db.verileriListele("select *from ucretler");
				try {
					
					while (rs.next()) {  //yeni bir sat�r verisi varsa, o verileri de g�rmek i�in kullan�l�r
						int id = rs.getInt("id");
						String saat = rs.getString("saat");
						int fiyat = rs.getInt("fiyat");
						System.out.println("id: " +id);
						System.out.println("saat: " +saat);
						System.out.println("fiyat: " +fiyat);
						System.out.println("--------------");
						
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}else if(islemSayi==2) {
				
				ResultSet rs = db.verileriListele("select * from otopar_yerleri");
				try {
					while (rs.next()) {
						int yer_id = rs.getInt("id");
						String lokasyon_adi = rs.getString("lokasyon_adi");
						int kapasite = rs.getInt("kapasite");
						System.out.println("Yer id: "+yer_id);
						System.out.println("Yer id: "+lokasyon_adi);
						System.out.println("Yer id: "+kapasite);
						
						System.out.println("--------");

						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}else if(islemSayi==3) {
				
				/*
				 insert into araclar(
	    		otopark_yer_id,plaka,otopark_giris_tarihi,
				)values (
	    		1,'34AA1234','16.11.2019'
				)
				 */
				
				System.out.println("L�tfen otopark yer id giriniz: ");
				int yer_id = sc.nextInt();
				System.out.println("L�tfen plaka giriniz: ");
				String plaka = sc.next();
				
				
				
		
				

				db.veriEkle("araclar", "otopark_yer_id,plaka,otopark_giris_tarihi", +yer_id+ ",'" +plaka+ "',now()");
				
				/*
				 * 
				 * db.veriEkle("araclar", 
				 * "otopark_yer_id,plaka,otopark_giris_tarihi", 
						"1,'34AA1234',now()");
				 */
						
				
				
				
			}else if(islemSayi==4) {
				
				System.out.println("L�tfen ��k�� yapmak istedi�iniz arac�n plakas�n� girin");
				String plaka = sc.next();
				Date suankiTarih = new Date();
				Date girisTarihi = null;
				int otopark_yer_id=0;
				
				ResultSet rs = db.verileriListele(
						"select otopark_giris_tarihi,otopark_yer_id from araclar where plaka='"+plaka+"'"
						);
				
				
				
				try {
					rs.next();
					girisTarihi = rs.getDate("otopark_giris_tarihi");
					otopark_yer_id = rs.getInt("otopark_yer_id");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				int gecenSaat = saatFarkiniHesapla(suankiTarih,girisTarihi);
				System.out.println(gecenSaat);
				
				if (gecenSaat>=0 && gecenSaat<=1) {
				
					System.out.println("Arac�n �cretsiz ��k��� yap�lm��t�r");
					db.veriEkle("kasa",
							"yer_id,alinan_ucret,tarih",
							otopark_yer_id+",0,now()");
				}else if (gecenSaat>1 && gecenSaat<3) {
					System.out.println("1-3 saat: 5 tl �deme al�nm��t�r");
					db.veriEkle("kasa",
							"yer_id,alinan_ucret,tarih",
							otopark_yer_id+",5,now()");
				}else if (gecenSaat>=3 && gecenSaat<7) {
					System.out.println("3-7 saat: 8 tl �deme al�nm��t�r");
					db.veriEkle("kasa",
							"yer_id,alinan_ucret,tarih",
							otopark_yer_id+",8,now()");
				}else if (gecenSaat>=7 && gecenSaat<15) {
					System.out.println("7-15 saat: 20 tl �deme al�nm��t�r");
					db.veriEkle("kasa",
							"yer_id,alinan_ucret,tarih",
							otopark_yer_id+",20,now()");
				}else if (gecenSaat>=15) {
					System.out.println("15+ saat: 25 tl �deme al�nm��t�r");
					db.veriEkle("kasa",
							"yer_id,alinan_ucret,tarih",
							otopark_yer_id+",25,now()");
				}
				
				
				
				
				db.veriGuncelle("araclar",
					"otopark_cikis_tarihi=now(),otopark_bekleme_tarihi="+gecenSaat+",ucret_kesildimi=1",
					"plaka='"+plaka+"'");
				
				
			}else if(islemSayi==5) {
				
				System.out.println("L�tfen otopark yer id giriniz");
				int yerid = sc.nextInt();
				
				
				ResultSet rs = db.verileriListele(
						"select sum(alinan_ucret) as toplam from kasa where yer_id="+yerid
						);
				
				try {
					rs.next();
					System.out.println("�lgili otopark�n toplam kazanc�: "+rs.getInt("toplam"));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}else if(islemSayi==6) {
				
				System.out.println("L�tfen otopark id'si giriniz");
				int otopark_id = sc.nextInt();
				
				ResultSet rs = db.verileriListele(
						"select * from araclar where ucret_kesildimi=0 and otopark_yer_id="+otopark_id
						);
				
				try {
					while(rs.next()) {
						
						System.out.println("Arac�n plakas�: "+rs.getString("plaka"));
						System.out.println("Arac�n giri� tarihi: "+rs.getDate("otopark_giris_tarihi").toString());
					//	System.out.println("Arac�n ��k�� tarihi: "+rs.getDate("otopark_cikis_tarihi").toString());
						System.out.println("Ara� otoparkta m�/�cret kesildi mi? : "+rs.getInt("ucret_kesildimi"));
						System.out.println("Beklenen saat: "+rs.getInt("otopark_bekleme_tarihi"));
						System.out.println("Otopark yer id: "+rs.getInt("otopark_yer_id"));
						System.out.println("------------------");

						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}else if(islemSayi==7) {
				
				System.out.println("L�tfen otopark id'si giriniz");
				int otopark_id = sc.nextInt();
				int toplam = db.tablodakiVeriSayisi("araclar","ucret_kesildimi=0 and otopark_yer_id="+otopark_id);
				
				System.out.println("Otoparktaki toplam ara� say�s�: "+toplam);
				
			}else if(islemSayi==8) {
				

				System.out.println("L�tfen otopark id'si giriniz");
				int otopark_id = sc.nextInt();
				
				ResultSet rs = db.verileriListele(
						"select * from araclar where ucret_kesildimi=1 and otopark_yer_id="+otopark_id
						);
				
				try {
					while(rs.next()) {
						
						System.out.println("Arac�n plakas�: "+rs.getString("plaka"));
						System.out.println("Arac�n giri� tarihi: "+rs.getDate("otopark_giris_tarihi").toString());
					    System.out.println("Arac�n ��k�� tarihi: "+rs.getDate("otopark_cikis_tarihi").toString());
						System.out.println("Ara� otoparkta m�/�cret kesildi mi? : "+rs.getInt("ucret_kesildimi"));
						System.out.println("Beklenen saat: "+rs.getInt("otopark_bekleme_tarihi"));
						System.out.println("Otopark yer id: "+rs.getInt("otopark_yer_id"));
						System.out.println("------------------");

						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}else {
				System.out.println("\nHatal� i�lem se�imi, yeniden deneyiniz!\n");
				continue;
			}


			
			

			
		}
		
	}

}
