
public class Ornek7 {
	
	public String terstenYazdir(String yazi) {
		String gecici = "";
		for (int i = yazi.length()-1; i >= 0; i--) {
			gecici += yazi.charAt(i);
		}
		return gecici;
	}

	public static void main(String[] args) {
		// yaz�y� tersten yazd�rmak i�in
		
		String yazi = "�ER�F G�NG�R";
		Ornek7 o = new Ornek7();
		System.out.println(o.terstenYazdir(yazi));

	}

}
