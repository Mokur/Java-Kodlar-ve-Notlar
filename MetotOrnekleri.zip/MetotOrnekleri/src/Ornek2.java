import java.util.Scanner;

public class Ornek2 {

	public static void forDongu(int baslangic, int son) {
		for (int i = baslangic; i <= son; i++) {
			System.out.println(i);
		}
		
	}
	
	public static void foreachDongu() {
		int[] sayilar = {1,2,3,4,5,6,7,8,9,10};
		for (int i : sayilar) {
			System.out.println(i);
		}
	}
	
	public static void whileDongu(int baslangic, int son) {
		int i = baslangic;
		while(i < son) {
			System.out.println(i);
			i++;
		}
	}
	
	public static void doWhileDongu(int baslangic, int son) {
		int i = baslangic;
		do {
			System.out.println(i);
			i++;
		}while (i <= son);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		System.out.println("For ile: ");
		forDongu(0,10);
		
		System.out.println("Do while ile: ");
		doWhileDongu(0,30);

		System.out.println("Foreach ile: ");
		foreachDongu();
		
		System.out.println("While ile: ");
		whileDongu(0,20);
		
		
		
		
	}

}
