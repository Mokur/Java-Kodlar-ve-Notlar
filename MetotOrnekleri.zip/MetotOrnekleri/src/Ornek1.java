import java.util.Scanner;

public class Ornek1 {

	
	public static double kareAlan(double kenar) {
		double alan = kenar*kenar;
		return alan;
	}
	
	public static double kareCevre(double kenar) {
		double cevre = kenar*4;
		return cevre;
	}
	
	public static double daireAlan(double yaricap) {
		double pi = 3.14;
		double alan = pi*yaricap*yaricap;
		return alan;
	}
	
	public static double daireCevre(double yaricap) {
		double pi = 3.14;
		
		//double cevre = 2 * Math.PI * yaricap;
		double cevre = 2 * pi * yaricap;
		return cevre;
	}
	
	public static double dDortgenAlan(double kisaK, double uzunK) {
		double alan = kisaK*uzunK;
		return alan;
	}
	
	public static double dDortgenCevre(double kisaK, double uzunK) {
		double cevre = 2*(kisaK+uzunK);
		return cevre;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Bir �ekil se�in(kare - dikd�rtgen - daire):  ");
		
		String sekil = sc.next();
		
		System.out.println("��lemi se�in (Alan - �evre):");
		
		String islem = sc.next();
		
		
		if("kare".equals(sekil)) {
			if("alan".equals(islem)) {
				System.out.println("Karenin bir kenar uzunlu�unu giriniz: ");
				double kenar = sc.nextDouble();
				System.out.println("Kare Alan: " +kareAlan(kenar));
			}else if("cevre".equals(islem)) {
				System.out.println("Karenin bir kenar uzunlu�unu giriniz: ");
				double kenar = sc.nextDouble();
				System.out.println("Kare �evre: " +kareCevre(kenar));
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}else if("dikd�rtgen".equals(sekil)) {
			
			if("alan".equals(islem)) {
				System.out.println("Dikd�rtgenin k�sa kenar uzunlu�unu giriniz: ");
				double kisaK = sc.nextDouble();
				System.out.println("Dikd�rtgenin uzun kenar uzunlu�unu giriniz: ");
				double uzunK = sc.nextDouble();
				System.out.println("Dikd�rtgen Alan: " +dDortgenAlan(kisaK,uzunK));
			}else if("cevre".equals(islem)) {
				System.out.println("Dikd�rtgenin k�sa kenar uzunlu�unu giriniz: ");
				double kisaK = sc.nextDouble();
				System.out.println("Dikd�rtgenin uzun kenar uzunlu�unu giriniz: ");
				double uzunK = sc.nextDouble();
				System.out.println("Dikd�rtgen �evre: " +dDortgenCevre(kisaK,uzunK));
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}else if("daire".equals(sekil)) {
			
			if("alan".equals(islem)) {
				System.out.println("Dairenin yaricap uzunlu�unu giriniz: ");
				double yaricap = sc.nextDouble();
				System.out.println("Daire Alan: " +daireAlan(yaricap));
				
			}else if("cevre".equals(islem)) {
				System.out.println("Dairenin yaricap uzunlu�unu giriniz: ");
				double yaricap = sc.nextDouble();
				daireCevre(yaricap);
				System.out.println("Daire �evre: " +daireCevre(yaricap));
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}else {
			System.out.println("ge�ersiz �ekil");
		}
		
	}

	

}
