import java.util.Scanner;

public class Ornek4 {

	
public static String akrostis(String[] kelime) {
		String yeniKelime = "";
		
		for (int i = 0; i < kelime.length; i++) {
			 yeniKelime += kelime[i].charAt(0);
		}
		
		return yeniKelime;
	}
	
	
	
	public static void main(String[] args) {
		// d��ar�dan n adet kelime iste, o kelimeleri bi diziye at, ilk karakterleri bir string i�erisinde birle�tirip ekrana ayzd�r, string d�ner
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ka� adet kelime giriceksiniz: ");
		int adet = sc.nextInt();
		
		String[] kelime = new String[adet] ;
		for (int i = 0; i < adet; i++) {
			System.out.println((i+1)+". kelimeyi girin: ");
			kelime[i] = sc.next();
			
		}
		
		
		
		System.out.println(akrostis(kelime));
		
		
		
	}

}
