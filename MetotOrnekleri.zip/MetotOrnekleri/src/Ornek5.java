import java.util.Scanner;

public class Ornek5 {

	public static String notHesapla(double vize, double finaln) {
	
		String str = null;
		double ort = (vize*0.4)+(finaln*0.6);
		
		if(ort >=0 && ort >= 10) {
			str = "FF";
		}else if(ort> 10 && ort >= 20) {
			str = "FD";
		}else if(ort> 21 && ort >= 30) {
			str = "DD";
		}else if(ort> 31 && ort >= 40) {
			str = "DC";
		}else if(ort> 41 && ort >= 50) {
			str = "CC";
		}else if(ort> 51 && ort >= 60) {
			str = "CB";
		}else if(ort> 61 && ort >= 70) {
			str = "BB";
		}else if(ort> 71 && ort >= 80) {
			str = "BA";
		}else if(ort> 81) {
			str = "AA";
		}
			
		return str;
	}
	
	
	public static void main(String[] args) {
		// d��ar�dan ki�inin vize final notunu iste ort hesapla  string d�nd�rs�n ff ise kald�n 
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Vize notunu girin: ");
		double vize = sc.nextDouble();
		

		System.out.println("Final notunu girin: ");
		double finaln = sc.nextDouble();
		
		String sonuc = notHesapla(vize,finaln);
		
		if("FF".equals(sonuc)) {
			System.out.println(sonuc +" ile kald�n�z!");
		}else if("FD".equals(sonuc)) {
			System.out.println(sonuc +" ile kald�n�z! ");
		}else if("DD".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("DC".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("CC".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("CB".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("BB".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("BA".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else if("AA".equals(sonuc)) {
			System.out.println(sonuc +" ile ge�tiniz!");
		}else {
			System.out.println("ge�ersiz");
		}
		
		
	}

}
