import java.util.Scanner;

public class Ornek6 {
	
	
	public int karakterSayisi(String[] str, char harf) {
		int sonuc=0;
		//string dizisi elemanlar�n� d�nmek i�in kulan�l�r
		
		for (int i = 0; i < str.length; i++) {
			//ilgili string dizisi elemanlar�n�n karakter uzunlu�u kadar d�ns�n
			for (int j = 0; j < str[i].length(); j++) {
				if(str[i].charAt(j)==Character.toUpperCase(harf) || str[i].charAt(j) == Character.toLowerCase(harf)) {
					sonuc++;
				}
			}
		}
		return sonuc;
	}
	
	
	//belirtti�imiz stringin i�erisindeki ilgili karakterin say�s�n� bulma
	
	public int karakterSayisi(String str, char harf) {
		int sonuc = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i)==Character.toUpperCase(harf) || str.charAt(i)==Character.toLowerCase(harf) ) {
				sonuc++;
			}
		}
		return sonuc;
	}
	
	

	public static void main(String[] args) {
		// belirlenen karakterin say�s�n� bulan metot
		// d��ar�dan 5 yaz� girip  bunlar�n i�inde ka� adet belirtti�imiz karakterin oldu�unu bulma
		
		
		Scanner sc = new Scanner(System.in);
		
		String[] dizi = new String[5];
		
		for(int i = 0; i < 5; i++) {
			System.out.println("L�tfen bir metin giriniz:");
			dizi[i] = sc.nextLine();
		}
		
		Ornek6 karakter = new Ornek6();
		
		System.out.println("Karakter giriniz: ");
		char harf = sc.next().charAt(0);
		int toplamSayi = karakter.karakterSayisi(dizi,harf);
		
		System.out.println("Dizi elemanlar�nds toplam: " +toplamSayi+ " adet" +harf+" bulunmaktad�r");

	}

}
