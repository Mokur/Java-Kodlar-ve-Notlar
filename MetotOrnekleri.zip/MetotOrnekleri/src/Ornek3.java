import java.util.Scanner;

public class Ornek3 {

	
	
	public static void sayilariYazdir(int baslangic, int son, String tc) {
		if("t".equals(tc)) {
			for (int i = baslangic; i <= son; i++) {
				if(i%2==1) {
					System.out.println(i);
				}
					
			}
		}else if("c".equals(tc)) {
			for (int i = baslangic; i < son; i++) {
				if(i%2==0) {
					System.out.println(i);
				}
			}
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ba�lang�� de�eri giriniz: ");
		int baslangic = sc.nextInt();
		
		System.out.println("Son de�eri giriniz: ");
		int son = sc.nextInt();
		
		
		System.out.println("Tek - �ift se�imi yap�n�z (t - c): ");
		String tc = sc.next();
		
		
		if("t".equals(tc)) {
			
		}else if("c".equals(tc)) {
			
		}else {
			System.out.println("ge�ersiz");
		}
		
		sayilariYazdir(baslangic,son,tc);
		
	}

}
