
public class Veritabani_deneme extends Veritabani{

	public static void main(String[] args) {


		if(baglan("Z:/deneme.db")) {
			System.out.println("Veritaban�na ba�ar�l� �ekilde ba�lan�ld�");
		}else {
			System.out.println("Veritaban�na ba�lan�rken bir sorun olu�tu");
		}

		
	}

}
