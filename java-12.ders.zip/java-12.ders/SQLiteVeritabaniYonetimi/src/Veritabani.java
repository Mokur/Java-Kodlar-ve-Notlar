
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Veritabani {

	static Connection conn = null;

	public static boolean baglan(String dbLokasyonu) {
		boolean response = false;
		try {
			// db parameters
			String url = "jdbc:sqlite:" +dbLokasyonu; //standart bu hep yaz�l�r

			
			Class.forName("org.sqlite.JDBC");
			
			conn = DriverManager.getConnection(url);

			// System.out.println("Veritaban�na ba�lant� sa�land�");

			response = true;

		} catch (SQLException e) {
			System.out.println("Veritaban�na ba�lant� sa�lanamad� (" +e.getMessage()+")");

		}
		
		catch (ClassNotFoundException e) {
			System.out.println("Veritaban�na ba�lant� sa�lanamad� (" +e.getMessage()+")");

		}

		return response;

	}

	public static void baglantiyiKapat() {
		try {
			if (conn != null) { // connection nesnesi tan�ms�z de�il ise
				conn.close(); // veritaban� ba�lant�s�n� kapat
			}
		} catch (SQLException ex) { // veritaban� hatas� var ise
			System.out.println(ex.getMessage()); // hatay� g�ster

		}

	}
}
