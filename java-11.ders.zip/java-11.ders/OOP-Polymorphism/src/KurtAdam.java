
public class KurtAdam extends Adam implements Kurt{

	@Override
	public void ulu() {
		// TODO Auto-generated method stub
		System.out.println("Uludum");
		
	}

	@Override
	public void kos() {
		// TODO Auto-generated method stub
		System.out.println("Ko�tum");

	}

	@Override
	public void isir() {
		// TODO Auto-generated method stub
		System.out.println("Is�rd�m");

	}

	@Override
	public void avlan() {
		// TODO Auto-generated method stub
		System.out.println("Avland�m");

	}

	
}
