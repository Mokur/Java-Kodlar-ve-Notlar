
public class Insan {
//y�r�, yemek ye, �ark� s�yle
	
	
	public void yuru() {
		System.out.println("Y�r�d�m");
	}
	
	public void yemekYe() {
		System.out.println("Yemek Yedim");

	}
	
	public void sarkiSoyle() {
		System.out.println("�ark� S�yledim");

	}
}
