
public interface Yarasa {
//�s�r u�
	
	public void isir();
		
	
	public void uc();
}
