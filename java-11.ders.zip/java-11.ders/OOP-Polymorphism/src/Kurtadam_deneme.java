
public class Kurtadam_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		KurtAdam kurtAdam = new KurtAdam();
		
		kurtAdam.isir();
		kurtAdam.kos();
		kurtAdam.ulu();
		kurtAdam.dansEt();


		
	}

}
