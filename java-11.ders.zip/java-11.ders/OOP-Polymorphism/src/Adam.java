
public class Adam {

	
	public void konus() {
		System.out.println("Konu�tum");
	}
	
	
	public void yuru() {
		System.out.println("Y�r�d�m");

	}
	
	public void gul() {
		System.out.println("G�ld�m");

	}
	
	public void agla() {
		System.out.println("A�lad�m");

	}
	
	public void dansEt() {
		System.out.println("Dans ettim");

	}
}
