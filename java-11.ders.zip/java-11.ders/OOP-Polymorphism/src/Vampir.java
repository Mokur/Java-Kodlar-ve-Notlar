
public class Vampir extends Insan implements Yarasa {

	@Override
	public void isir() {
		System.out.println("Is�rd�m");

		
	}

	@Override
	public void uc() {
		System.out.println("U�tum");
		
	}

}
