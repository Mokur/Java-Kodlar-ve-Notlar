
public class Araba_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Araba araba = new Araba(); //abstract y�z�nden ayn� s�n�ftan newleme yap�lam�yor direk
		
		Araba araba2 = new MotorluTasitlar(); // dolayl� yoldan farkl� bir class �zerinden �rettik. 
		
		MotorluTasitlar motorluTasitlar =new MotorluTasitlar();
	}

}
