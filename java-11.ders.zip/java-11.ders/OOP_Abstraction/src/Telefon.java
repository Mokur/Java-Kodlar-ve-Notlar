
public class Telefon extends Iphone {

	

	
	
}
