
public class Bilgisayar {

	
	
	private double fiyat;
	private String marka;
	private String model;
	private String islemciAdi;
	private int ram;
	private int grafik;
	private String isletimSistemi;
	private int uretimYili;
	private double ekranBoyutu;
	private boolean dokunmatikEkran;
	private boolean laptopMi;
	private boolean multiBoot;
	
	
	
	public Bilgisayar() {
		
	}



	public Bilgisayar(double fiyat, String marka, String model, String islemciAdi, int ram, int grafik,
			String isletimSistemi, int uretimYili, double ekranBoyutu, boolean dokunmatikEkran, boolean laptopMi,
			boolean multiBoot) {
		super();
		this.fiyat = fiyat;
		this.marka = marka;
		this.model = model;
		this.islemciAdi = islemciAdi;
		this.ram = ram;
		this.grafik = grafik;
		this.isletimSistemi = isletimSistemi;
		this.uretimYili = uretimYili;
		this.ekranBoyutu = ekranBoyutu;
		this.dokunmatikEkran = dokunmatikEkran;
		this.laptopMi = laptopMi;
		this.multiBoot = multiBoot;
	}



	public double getFiyat() {
		return fiyat;
	}



	public void setFiyat(double fiyat) {
		this.fiyat = fiyat;
	}



	public String getMarka() {
		return marka;
	}



	public void setMarka(String marka) {
		this.marka = marka;
	}



	public String getModel() {
		return model;
	}



	public void setModel(String model) {
		this.model = model;
	}



	public String getIslemciAdi() {
		return islemciAdi;
	}



	public void setIslemciAdi(String islemciAdi) {
		this.islemciAdi = islemciAdi;
	}



	public int getRam() {
		return ram;
	}



	public void setRam(int ram) {
		this.ram = ram;
	}



	public int getGrafik() {
		return grafik;
	}



	public void setGrafik(int grafik) {
		this.grafik = grafik;
	}



	public String getIsletimSistemi() {
		return isletimSistemi;
	}



	public void setIsletimSistemi(String isletimSistemi) {
		this.isletimSistemi = isletimSistemi;
	}



	public int getUretimYili() {
		return uretimYili;
	}



	public void setUretimYili(int uretimYili) {
		this.uretimYili = uretimYili;
	}



	public double getEkranBoyutu() {
		return ekranBoyutu;
	}



	public void setEkranBoyutu(double ekranBoyutu) {
		this.ekranBoyutu = ekranBoyutu;
	}



	public boolean isDokunmatikEkran() {
		return dokunmatikEkran;
	}



	public void setDokunmatikEkran(boolean dokunmatikEkran) {
		this.dokunmatikEkran = dokunmatikEkran;
	}



	public boolean isLaptopMi() {
		return laptopMi;
	}



	public void setLaptopMi(boolean laptopMi) {
		this.laptopMi = laptopMi;
	}



	public boolean isMultiBoot() {
		return multiBoot;
	}



	public void setMultiBoot(boolean multiBoot) {
		this.multiBoot = multiBoot;
	}
	
	
	
	
}
