
public class Insan {
//isim ya�  cinsiyet(char e k) boy kilo 
	
	
	private String isim;
	private int yas;
	private char cinsiyet;
	private float boy;
	private float kilo;
	
	
	public Insan() {
		
		
	}


	public Insan(String isim, int yas, char cinsiyet, float boy, float kilo) {
		super();
		this.isim = isim;
		this.yas = yas;
		this.cinsiyet = cinsiyet;
		this.boy = boy;
		this.kilo = kilo;
	}


	public String getIsim() {
		return isim;
	}


	public void setIsim(String isim) {
		this.isim = isim;
	}


	public int getYas() {
		return yas;
	}


	public void setYas(int yas) {
		this.yas = yas;
	}


	public char getCinsiyet() {
		return cinsiyet;
	}


	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}


	public float getBoy() {
		return boy;
	}


	public void setBoy(float boy) {
		this.boy = boy;
	}


	public float getKilo() {
		return kilo;
	}


	public void setKilo(float kilo) {
		this.kilo = kilo;
	}
	
	
	
	
}
