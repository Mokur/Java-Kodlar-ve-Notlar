
public class Insan_Deneme {

	public static void main(String[] args) {
		
		//String isim, int yas, char cinsiyet, float boy, float kilo
		
		Insan insan1, insan2, insan3;
		
		//dolu constructor seviyesinde nesneleri �retirken de�erleri g�nderdik
		insan1 = new Insan("Adem",30,'e',190,80);
		insan2 = new Insan("�erif",25,'e',178,85);
		insan3 = new Insan("Havva",20,'k',165,70);
		

		System.out.println(insan1.getIsim());
		System.out.println(insan2.getIsim());
		System.out.println(insan3.getIsim());
	}

}
