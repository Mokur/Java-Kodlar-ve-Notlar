import java.util.ArrayList;
import java.util.Scanner;

public class Bilgisayar_Deneme {

	public static void main(String[] args) {
		//bilgisayar tipinde arraylist �ret bilgisayarlar ad�nda
		
		//double fiyat, String marka, String model, String islemciAdi, int ram, int grafik,
		//String isletimSistemi, int uretimYili, double ekranBoyutu, boolean dokunmatikEkran, boolean laptopMi,
		//boolean multiBoot
		
		ArrayList<Bilgisayar> bilgisayarlar = new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ka� adet bilgisayar giri�i yap�lacak? ");
		int adet = sc.nextInt();

		for (int i = 0; i < adet; i++) {
			
			
			System.out.println("L�tfen marka giriniz: ");
			String marka = sc.next();
			
			System.out.println("Model giriniz: ");
			String model = sc.next();
			
			System.out.println("Fiyat bilgi giriniz: ");
			double fiyat = sc.nextDouble();
			
			System.out.println("��lemci bilgisi giriniz: ");
			String islemci = sc.next();
		
			System.out.println("Ram bilgisi giriniz: ");
			int ram = sc.nextInt();
			
			System.out.println("Grafik bilgisi giriniz: ");
			int grafik = sc.nextInt();
			
			System.out.println("��letim sistemini giriniz: ");
			String isletim = sc.next();
		
			System.out.println("�retim y�l�n� giriniz: ");
			int uretimYili = sc.nextInt();
			
			System.out.println("Ekran boyutunu giriniz: ");
			double ekranBoyutu = sc.nextDouble();
			
			System.out.println("Dokunmatik ekran m�(true-false) : ");
			boolean dokunmatikEkran = sc.nextBoolean();
			
			System.out.println("Laptop m�(true-false) : ");
			boolean laptopMi = sc.nextBoolean();
			
			System.out.println("Multiboot mu(true-false) : ");
			String multiBoot = sc.next();
			
			boolean multiBootMu = false;
			if ("true".equals(multiBoot)) {
				multiBootMu = true;
			}
			
			
			/*
			 * 
			 * double fiyat, String marka, String model, String islemciAdi, int ram, int grafik,
			String isletimSistemi, int uretimYili, double ekranBoyutu, boolean dokunmatikEkran, boolean laptopMi,
			boolean multiBoot
			 */
			
			Bilgisayar b = new Bilgisayar(fiyat,marka,model,islemci,ram,grafik,isletim,uretimYili,ekranBoyutu,dokunmatikEkran,laptopMi,multiBootMu);
			bilgisayarlar.add(b);
			
			
			
			for (int j = 0; j < bilgisayarlar.size(); j++) {
				System.out.println("Bilgisayar�n markas�: " +bilgisayarlar.get(i).getMarka());
				System.out.println("Bilgisayar�n modeli: " +bilgisayarlar.get(i).getModel());
				System.out.println("Bilgisayar�n fiyat�: " +bilgisayarlar.get(i).getFiyat());

				
			}
		}
		
		
	}

}
