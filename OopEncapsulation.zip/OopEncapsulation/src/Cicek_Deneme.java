
public class Cicek_Deneme {

	public static void main(String[] args) {
		
		Cicek cicek = new Cicek(); //newleme yapmak / nesne �retmek
		cicek.setCins("Cins");
		cicek.setDikenliMi(true);
		cicek.setEnFazlaYukseklik(2000);
		cicek.setIsim("G�l");
		cicek.setKokuluMu(true);
		cicek.setRenk("K�rm�z�");
		cicek.setYetistigiBolge("Turkiye");
		cicek.setSaksidaMi(false);
		
		
		System.out.println("�ice�in cinsi: " +cicek.getCins());
		System.out.println("�i�e�in ismi: " +cicek.getIsim());
		System.out.println("Rengi: " +cicek.getRenk());
		System.out.println("�i�ek dikenli midir: " +cicek.isDikenliMi());
		System.out.println("En fazla Y�ksekli�i: " +cicek.getEnFazlaYukseklik());
		System.out.println("Kokulu mu: " +cicek.isKokuluMu());
		System.out.println("Saks�da m�: " +cicek.isSaksidaMi());
		System.out.println("Yeti�ti�i B�lge: " +cicek.getYetistigiBolge());
		
		
		
		
		
		String diken = cicek.isDikenliMi() ? "Dikenli" : "Dikensiz";
		System.out.println("�i�ek dikenli mi? : " +diken);
		
		
		String koku = cicek.isKokuluMu() ? "Kokulu" : "Kokusuz";
		System.out.println("�i�ek kokulu mu? : " +koku);
		
		String saksi = cicek.isSaksidaMi() ? "Saks�da" : "Saks�da De�il";
		System.out.println("�i�ek saks�da m�? : " +saksi);
		
		
		
		
		
	}

}
