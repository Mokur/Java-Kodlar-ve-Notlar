
public class Cicek {
	
	
	//her de�i�kenin private olarak tan�mlanmas�
	private String isim;
	private String renk;
	private String cins;
	private String yetistigiBolge;
	private boolean kokuluMu;
	private boolean dikenliMi;
	private boolean saksidaMi;
	private double enFazlaYukseklik;
	
	
	//bo� constructor
	public Cicek() {
		
	}
	
	
	//dolu constructor
	public Cicek(String isim,String renk,String cins,String yetistigiBolge,boolean kokuluMu,boolean dikenliMi,boolean saksidaMi,double enFazlaYukseklik ) {
		//this--> bu s�n�f�n i�indeki demek
		this.isim = isim;  //global alandaki (ba��nda private olan kk�s�m) isim de�i�kenine bu arg�mandan gelen isimi atam�� oluyoruz
		this.renk = renk;
		this.cins = cins;
		this.yetistigiBolge = yetistigiBolge;
		this.kokuluMu = kokuluMu;
		this.dikenliMi = dikenliMi;
		this.saksidaMi = saksidaMi;
		this.enFazlaYukseklik = enFazlaYukseklik;
		
	}

	
	
	
	
	
	
	/*
	 get metotlar(getter) de�i�ken de�erlerini �a��rmak i�in kullan�l�r
	 set metotlar(setter) dei�ken de�eri atamak i�in kullan�l�r
	 */

	public String getIsim() {
		return isim;
	}


	public void setIsim(String isim) {
		this.isim = isim;
	}


	public String getRenk() {
		return renk;
	}


	public void setRenk(String renk) {
		this.renk = renk;
	}


	public String getCins() {
		return cins;
	}


	public void setCins(String cins) {
		this.cins = cins;
	}


	public String getYetistigiBolge() {
		return yetistigiBolge;
	}


	public void setYetistigiBolge(String yetistigiBolge) {
		this.yetistigiBolge = yetistigiBolge;
	}


	public boolean isKokuluMu() {
		return kokuluMu;
	}


	public void setKokuluMu(boolean kokuluMu) {
		this.kokuluMu = kokuluMu;
	}


	public boolean isDikenliMi() {
		return dikenliMi;
	}


	public void setDikenliMi(boolean dikenliMi) {
		this.dikenliMi = dikenliMi;
	}


	public boolean isSaksidaMi() {
		return saksidaMi;
	}


	public void setSaksidaMi(boolean saksidaMi) {
		this.saksidaMi = saksidaMi;
	}


	public double getEnFazlaYukseklik() {
		return enFazlaYukseklik;
	}


	
	public void setEnFazlaYukseklik(double enFazlaYukseklik) {
		this.enFazlaYukseklik = enFazlaYukseklik;
	}
	
	


	
	
	
	
	
	
	
	
}
