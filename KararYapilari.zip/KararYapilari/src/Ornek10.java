import java.util.Scanner;

public class Ornek10 {

	public static void main(String[] args) {
		// kelimede a olmayan karakterleri yazd�rma
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("��erisinde a olan bir c�mle giriniz: ");
		
		String yazi = sc.nextLine();
		
		
		int uzunluk = yazi.length();
		
		for(int i=0; i<uzunluk; i++) {
			if(yazi.charAt(i)!='a') {
				System.out.println(yazi.charAt(i));
			}
		}

	}

}
