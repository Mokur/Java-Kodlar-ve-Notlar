import java.util.Scanner;

public class Ornek7 {

	static Scanner sc;
	public static void main(String[] args) {
		// daire kare dikd�rtgen �evre ve alan 

		sc = new Scanner(System.in);
		
		System.out.println("Bir �ekil se�iniz (daire - kare - dikd�rtgen):");
		String sekil = sc.next();
		
		System.out.println("��lem se�iniz (alan - �evre):");
		String islem = sc.next();
		 
		if("dikd�rtgen".equals(sekil)) {
			System.out.println("Uzun kenar� giriniz: ");
			int uKenar = sc.nextInt();
			System.out.println("K�sa kenar� giriniz: ");
			int kKenar = sc.nextInt();
			
			if("�evre".equals(islem)) {
				System.out.println("Dikd�rtgen �evresi: " +(2*(uKenar+kKenar)));
			}else if("alan".equals(islem)) {
				System.out.println("Dikd�rtgen Alan�: " +(uKenar*kKenar));
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}else if("kare".equals(sekil)) {
			System.out.println("Kenar uzunlu�u giriniz:");
			int kenar = sc.nextInt();
			
			if("�evre".equals(islem)) {
				System.out.println("Kare �evresi: " +(4*kenar));
			}else if("alan".equals(islem)) {
				System.out.println("Alan �evresi: " +(kenar*kenar));
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}else if("daire".equals(sekil)) {
			System.out.println("Yar��ap uzunlu�u giriniz: ");
			int yaricap = sc.nextInt();
			
			if("�evre".equals(islem)) {
				System.out.println("Dairenin �evresi: " +(2*3.14*yaricap));
				
			}else if("alan".equals(islem)) {
				System.out.println("Dairenin alan�: " +(3.14*yaricap*yaricap));
				
			}else {
				System.out.println("ge�ersiz i�lem");
			}
		}
	}

}
