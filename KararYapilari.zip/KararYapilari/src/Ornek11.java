
public class Ornek11 {

	public static void main(String[] args) {
		// hata t�rleri
		
		

	}

}
