import java.util.Scanner;

public class Ornek3 {

	static Scanner sc;
	public static void main(String[] args) {
		//mevsim ad� iste, o mevsime ait aylar� yazd�r
		
		
		sc= new Scanner(System.in);
		
		System.out.println("Bir mevsim giriniz:");
		String mevsim= sc.next();
		
		
		
		if("ilkbahar".equalsIgnoreCase(mevsim)) {
			System.out.println("Mart - Nisan - May�s");
		}else if("yaz".equalsIgnoreCase(mevsim)) {
			System.out.println("Haziran - Temmuz - A�ustos");
		}else if("sonbahar".equalsIgnoreCase(mevsim)) {
			System.out.println("Eyl�l - Ekim - Kas�m");
		}else if("k��".equalsIgnoreCase(mevsim)) {
			System.out.println("Aral�k - Ocak - �ubat");
		}else {
			System.out.println("Ge�ersiz giri�");
		}
		

	}

}
