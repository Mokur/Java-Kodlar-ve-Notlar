import java.util.Scanner;

public class Ornek4 {

	static Scanner sc;
	public static void main(String[] args) {
		// say� 1 ve 2 iste, i�lemi de se�sin ona g�re sonucu yazd�r
		
		sc= new Scanner(System.in);
		
		System.out.println("birinci say�:");
		int sayi1= sc.nextInt();
		
		System.out.println("birinci say�:");
		int sayi2= sc.nextInt();
		
		System.out.println("i�lemi se�iniz(+ - * /):");
		String islem= sc.next();
		
		if("+".equals(islem)) {
			System.out.println("��lemin sonucu:" +(sayi1+sayi2));
		}else if("-".equals(islem)) {
			System.out.println("��lemin sonucu:" +(sayi1-sayi2));
		}else if("*".equals(islem)) {
			System.out.println("��lemin sonucu:" +(sayi1*sayi2));
		}else if("/".equals(islem)) {
			System.out.println("��lemin sonucu:" +(float)(sayi1/sayi2));
		}else {
			System.out.println("ge�ersiz giri�");
		}
			
	}

}
