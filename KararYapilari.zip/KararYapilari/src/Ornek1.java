
public class Ornek1 {

	public static void main(String[] args) {

		String username = "admin";
		String password="1234";
		
		if("admin".equals(username) && "1234".equals(password)) {
			System.out.println("Ho�geldin");
		}else {
			System.out.println("Kullan�c� ad� ya da �ifre hatal�!");
		}
		
		/*
		 * Birden fazla �art� tek bir if blo�u i�erisinde saklayabiliriz.
		 * belirtti�imiz operat�re g�re mant�ksal sorgulama yap�p if blo�u 
		 * i�erisine girebilir ya da girmeyebilir
		 * 
		 * && -> ve
		 * || -> veya ya da
		 * 
		 */
		
		
		
	}

}
