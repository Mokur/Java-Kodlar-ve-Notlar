import java.util.Scanner;

public class Ornek2 {

	static Scanner sc;
	public static void main(String[] args) {
	//13ten k���kse,  ya� isim, ya� 20 25ten 26 
		
		sc = new Scanner(System.in);
		
		System.out.println("Ad girin:");
		String isim= sc.next();
		
		System.out.println("Ya��n�z� girin:");
		int yas= sc.nextInt();
		
		if(yas <= 0) {
			System.out.println("Ya��n�z belirtilen aral�kta de�ildir");
		}else if(yas < 13 && yas > 1) {
			System.out.println("Ya��n�z 13'ten k���kt�r");
		}else if(yas == 20){
			System.out.println("Ya��n�z 20'dir");
		}else if(yas > 20 && yas < 25) {
			System.out.println("Ya��n�z 20-25 aras�ndad�r");
		}else if(yas >= 26){
			System.out.println("Ya��n�z 26 veya 26'dan b�y�kt�r");

		}
	 
	
	
	

	}

}
