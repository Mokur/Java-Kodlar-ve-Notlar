import java.util.Scanner;

public class Ornek8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String mevsim = sc.next();
		mevsim = mevsim.toLowerCase();
		
		switch(mevsim) {
		case "sonbahar":
			System.out.println("Eyl�l - Ekim - Kas�m");
			break;
		case "k��":
			System.out.println("Aral�k - Ocak - �ubat");

			break;
		case "ilkbahar":
			System.out.println("Mart - Nisan - May�s");

			break;
		case "yaz":
			System.out.println("Haziran - Temmuz - A�ustos");

			break;
			default:
				System.out.println("B�yle bir mevsim yok!");

				break;
				
		}

	}

}
