import java.util.Scanner;

public class Ornek6 {

	static Scanner sc;
	public static void main(String[] args) {
		// ad soyad mes�lek ��retmense yazs�n ��renci yazarsa 
		//e�er ��renciyse ya��n� iste ya��n� da yazd�r

	//ya�� 20 ise ya� 20 yazs�n 
		
		sc = new Scanner(System.in);
		
		System.out.println("Ad ve soyad giriniz: ");
		String adSoyad = sc.nextLine();
		
		System.out.println("Mesle�inizi giriniz: ");
		String meslek = sc.next();
		
		if("��retmen".equalsIgnoreCase(meslek)) {
			System.out.println("Ad Soyad: " +adSoyad);
			System.out.println("Meslek: " +meslek);
		}else if("��renci".equalsIgnoreCase(meslek)) {
			System.out.println("Ya��n�z� giriniz:");
			int yas= sc.nextInt();
			if(yas==20) {
				System.out.println("Ya��n�z 20'dir");
			}else {
				System.out.println("Ya��n�z 20 de�ildir");
			}
		}

	}

}
