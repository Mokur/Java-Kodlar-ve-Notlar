
public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		short s = 5;
		boolean b = true;
		char ch = 'M';
		int i = 10;
		float f = 2.3f;
		String yazi = "Java Programlama 1";
		double d = 10.5d;
		long l = 154654568;
		byte by = 3;
		
		System.out.println(s);
		System.out.println(b);
		System.out.println(ch);
		System.out.println(i);
		System.out.println(f);
		System.out.println(yazi);
		System.out.println(d);
		System.out.println(l);
		System.out.println(by);

		System.out.print("�smek\nFatih\nBili�im\nOkulu");
		
	}

}
