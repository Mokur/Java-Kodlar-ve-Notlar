package donguKullanimlari;

import java.util.Scanner;

public class Ornek5 {

	public static void main(String[] args) {
		// n adet d��ar�dan de�er iste, ka� adet kelime girmek istiyosun o kadar d�ng�y� d�nd�r, kelimeleri iste, kelmelerin ilk karakterleri yeni dizide tut onu kelime olarak yazd�r
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ka� adet kelime girmek istiyosunuz?");
		int sayi = sc.nextInt();
		
		String[] dizi= new String[sayi];
		//String[] dizi2= new String[sayi];

		
		for(int i=0; i<sayi; i++) {
			
			System.out.println((i+1) +". kelimeyi girin:");
			
			dizi[i]= sc.next();
			//dizi2[]= dizi[i].charAt(arg0)
			
			
		}
		
		
		String gecici= "";
		for(int j=0; j<sayi; j++) {
			gecici+= dizi[j].charAt(0);
		}
		
		System.out.println(gecici);

	}

}
