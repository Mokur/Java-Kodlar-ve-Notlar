package donguKullanimlari;

import java.util.Scanner;

public class Ornek8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 0; i <= 10; i++) {

			for (int k = 0; k < 10 - i; k++) {

				System.out.print(" ");
			}

			for (int j = 0; j < 2 * i - 1; j++) {

				System.out.print("*");
			}

			System.out.print("\n");
		}

	}

}
