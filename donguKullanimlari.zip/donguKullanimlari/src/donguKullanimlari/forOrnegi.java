package donguKullanimlari;

public class forOrnegi {

	public static void main(String[] args) {
		/*
		 * 
		 * d�ng�ler:
		 * 1-for
		 * 2-while
		 * 3-do while
		 * 4-foreach
		 *
		 * 
		 */
		
		
		
		
		/*
		 * 
		 * 1.k�s�m:ba�lang�� de�eri
		 * 2.�art k�sm�
		 * 3.art�� ya da azal�� miktar�
		 */
		for(int i=0; i<10; i++) {
			System.out.println(i);
		}
		

		System.out.println("----");
		int i = 0;
		for(;;) {
			i++;
			System.out.println(i);
			if(i==500)
				break;
			 
			
		}
		
		
		
		//while d�ng�s�
		
		
		//bir �art  mant�ksal olarak true oldu�u s�rece �al���r
		
		int sayi= 0;
		
		while(sayi<=10) {
			/*
			 * 
			 * say�n�n ona e�it olma ve ondan k���k olmas� durumunda s�rekli d�nmesi
			 * parantez i�indeki �art k�sm� mant�ksal olarak ne zaman false d�nerse d�ng� o zaman sona erer.
			 */
			
			System.out.println("Merhaba");
			sayi++;
			
		}

		
		System.out.println("------------");
		
		//do while
		
		
		int s = 0;
		do {
			
			System.out.println(s);
			s++;
			
			
		}while(s<=10);
		
		//while �art� sa�lanmasa bile, do blo�u en az 1 defa �al���r. while �art� sa�lan�rsa do blo�u s�rekli �al���r
		
		
		
		
		//foreach �rne�i
		int[] dizi = {0,1,2,3,4,5,6,7,8,9};
		
		for(int eleman : dizi) {
			System.out.println(eleman);
		}
		
	}
	
	


	
	

	
	

}

