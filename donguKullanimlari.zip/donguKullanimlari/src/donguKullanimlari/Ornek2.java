package donguKullanimlari;

import java.util.Scanner;

public class Ornek2 {

	
	static Scanner sc;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		sc = new Scanner(System.in);
		
		String strDizi[]= new String[5];
		
		for(int i=0; i<5; i++) {
			System.out.println((i+1)+". ismi giriniz:");
			
			
			strDizi[i]=sc.next();
			
			
		}
		
		for(int j=0 ;j<5; j++)
		
			System.out.println(strDizi[j]);
		
		
	}

}
