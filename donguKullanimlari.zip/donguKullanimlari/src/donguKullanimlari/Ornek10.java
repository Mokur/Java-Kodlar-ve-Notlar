package donguKullanimlari;

public class Ornek10 {

	
	static void piramitUret(char karakter) {
		
		for (int i = 10; i > 0; i--) {
			int j;
			for (j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for (int k = j; k < 10; k++) {
				System.out.print(karakter+" ");
			}
			System.out.println("");
		}
	}
	
	
	
	
	static void sayiPiramitUret(int uzunluk) {
		
		//0'dan 10'akadar d�n sat�r �ret
		
		for (int i = 0; i <= uzunluk; i++) {
			for (int j = 0; j <= uzunluk; j++) { //bo�luklar� �ret
				System.out.print(" ");
			}
			for (int k = 0; k <=i; k++) {
				System.out.print(k+" ");
			}
			System.out.println("");
		}
	}
	public static void main(String[] args) {
		// Y�ld�z piramit �retimi
		
		piramitUret('+');
		sayiPiramitUret(10);
		
		//say� piramidi
		
		
		

	}

}
