package donguKullanimlari;

import java.util.Scanner;

public class Ornek3 {

	public static void main(String[] args) {
		// d��ar�dan 0 ile belirtti�imiz aral�k kadar de�erleri ekrana yazd�ran program� yaz�n�z, art�� miktar�n� da kullan�c�dan iste

		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println("Ka�a kadar arts�n?");
		int sayac = sc.nextInt();
		
		System.out.println("Art�� miktar� ne olsun?");
		int j = sc.nextInt();
		
	
		
		for(int i =0; i<= sayac; i+=j) {
			System.out.println(i);
		}
	}

}
