package donguKullanimlari;

import java.util.Scanner;

public class Ornek4 {

	public static void main(String[] args) {
		// 5 elemanl� string dizisi �ret, kullan�c�dan de�erleri iste ve ata ve yazd�r
		
		Scanner sc = new Scanner(System.in);
		
		String[] dizi = new String[5];
		
		for(int i=0; i<5; i++) {
			
			
			System.out.println((i+1)+". stringi girin: ");
			
			dizi[i]= sc.next();
			
		} 
		
		for (int j = 0; j < dizi.length; j++) {
			System.out.println(dizi[j]);
		}

	}

}
