package donguKullanimlari;

import java.util.Scanner;

public class Ornek9 {

	public static void main(String[] args) {
		// n adet say� iste, int diziye g�nder, birinci istemek i�in ikinci for say�olar� toplamak i�in , toplam sonucu yazd�r, teklerin toplam� �iftlerin toplam�
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ka� adet say� girmek istiyosunuz?");
		
		int sayi= sc.nextInt();
	
		int[] dizi= new int[sayi];
		
		int toplam= 0;
		int ciftToplam= 0;
		int tekToplam= 0;
		
		
		for (int i = 0; i < sayi; i++) {
			System.out.println((i+1) +". say�y� giriniz:");
			
			int deger= sc.nextInt();
			toplam+= deger;
			
			if(deger%2==0) {
				ciftToplam+=deger;
			}else {
				tekToplam+= deger;
			}
			
			


		}
		
		System.out.println("toplam:" +toplam);
		System.out.println("�iftlerin toplam�: " +ciftToplam);
		System.out.println("teklerin toplam�: " +tekToplam);
		
		 
		 

	}

}
