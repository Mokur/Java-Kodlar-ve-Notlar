package donguKullanimlari;

import java.util.Scanner;

public class Ornek6 {

	public static void main(String[] args) {
		// string iste alt alta yazd�r
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Bir string girin:");
		String str= sc.next();
		
		for (int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}

	}

}
