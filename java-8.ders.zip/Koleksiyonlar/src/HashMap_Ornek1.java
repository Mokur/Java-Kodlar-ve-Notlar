import java.util.HashMap;

public class HashMap_Ornek1 {

	public static void main(String[] args) {
		/*
		 * hashmap, key(anahtar) - value(de�er) ili�kisinde dee�r saklayabilmemizi sa�layan map s�n�f�d�r
		 * 
		 * 
		 * hashmap belirtilen tipte key ve yine belirtilen tipte value saklamam�za olanak tan�r
		 */

		
		//d��ar�dan n adet key ve value iste, a� adet istedi�ini sor, hashmap i�erisinde sakla daha sonra 
		
		
		HashMap<String,String> kelimeler = new HashMap<>();
		
		
		kelimeler.put("elma", "apple");
		kelimeler.put("kalem", "pencil");
		kelimeler.put("araba", "car");
		kelimeler.put("bilgisayar", "computer");
		
		
		System.out.println(kelimeler.get("elma"));

	}

}
