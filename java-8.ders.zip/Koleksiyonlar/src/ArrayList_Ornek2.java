import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek2 {

	public static void main(String[] args) {
		// d��ar�dan ka� adet yaz� girmesi gerekti�i iste, yaz�lar� isteyip arrayliste ata, 
		// arrayliste att���n yaz�lar� listele
		
		Scanner sc = new Scanner(System.in);
		

		System.out.println("Ka� adet yaz� girmek istiyosunuz?");
		int adet= sc.nextInt();
		
		ArrayList<String> yaziListe = new ArrayList<>();
		
		for (int i = 0; i < adet; i++) {
			System.out.println(i+1 +". stringi girin: ");
			String yazi = sc.next();
			yaziListe.add(yazi);
			
		}
		
		for (int i = 0; i < yaziListe.size(); i++) {
			System.out.println(yaziListe.get(i));
		}
		
	}

}
