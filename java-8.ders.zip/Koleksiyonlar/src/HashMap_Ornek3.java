import java.util.HashMap;

public class HashMap_Ornek3 {

	public static void main(String[] args) {
		// hashmap �nteger  il�eler isimli string  il�e posta kod ve il�e isimleri put metoduyla 5 defa key ve valuelar� listelet
		
		
		HashMap<Integer,String> ilceler = new HashMap<Integer,String>();
		
		ilceler.put(34200, "Beylikd�z�");
		ilceler.put(34500, "Bak�rk�y");
		ilceler.put(34300, "Be�ikta�");
		ilceler.put(34400, "B�y�k�ekmece");
		
		
		//de�erleri listelemek
		for (String ilceAdi : ilceler.values()) {
			System.out.println("�l�e Ad�: " +ilceAdi);
		}
		
		
		
		//keyleri listelemek
		for (Integer postaKodu : ilceler.keySet()) {
			System.out.println("Posta Kodu: " +postaKodu);
		}

	}

}
