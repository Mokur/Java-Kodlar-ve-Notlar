import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek4 {

	public static void main(String[] args) {
		//5 tane string iste, listeden silincek eleman ismi iste, onu silip listele
		
		
		Scanner sc = new Scanner(System.in);
		
		
		ArrayList<String> yaziListe = new ArrayList<>(); 
		
		for (int i = 0; i < 5; i++) {
			System.out.println(i+1 +". stringi girin:");
			String yazi = sc.next();
			yaziListe.add(yazi);
			
			
		}
		
		System.out.println("silinecek stringi yaz�n:");
		String silYazi = sc.next();
		
		yaziListe.remove(silYazi);
		
		for (int i = 0; i < yaziListe.size(); i++) {
			System.out.println(yaziListe.get(i));
		}
		
		
		
		//metot �ret d��ar�dan alma main i�inde meyveler string 
		//arraylist meyve isimleri yaz a ile ba�layan b ile ba�layan vs metotda arraylist g�nder harf g�nder ona g�re getirsin
		
		
		

	}

}
