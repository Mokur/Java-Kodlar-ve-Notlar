
public class Araba {

	
	
	private String marka;  // bu s�n�f d���nda herhangi bi s�n�ftan eri�ilmemesi i�in private yap�yoruz
	private String model;
	private int uretimYili;
	private String renk;
	private String vitesTuru;
	
	
	public Araba() {
		
	}
	
	
	
	
	public Araba(String marka, String model, int uretimYili, String renk, String vitesTuru) {
		super();
		this.marka = marka;
		this.model = model;
		this.uretimYili = uretimYili;
		this.renk = renk;
		this.vitesTuru = vitesTuru;
	}
	
	
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getUretimYili() {
		return uretimYili;
	}
	public void setUretimYili(int uretimYili) {
		this.uretimYili = uretimYili;
	}
	public String getRenk() {
		return renk;
	}
	public void setRenk(String renk) {
		this.renk = renk;
	}
	public String getVitesTuru() {
		return vitesTuru;
	}
	public void setVitesTuru(String vitesTuru) {
		this.vitesTuru = vitesTuru;
	}
	
	
	
	
}
