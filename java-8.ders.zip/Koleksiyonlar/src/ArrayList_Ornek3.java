import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek3 {

	public static void main(String[] args) {
		// kullan�c�dan hangi inisi silmek istedi�ini sor ve onu remove et
		
		
		Scanner sc = new Scanner(System.in);
		

		System.out.println("Ka� adet say� girmek istiyosunuz?");
		int adet= sc.nextInt();
		
		ArrayList<Integer> sayiListe = new ArrayList<>();
		
		for (int i = 0; i < adet; i++) {
			System.out.println(i+1 +". stringi girin: ");
			int sayi = sc.nextInt();
			sayiListe.add(sayi);
			
		}
		
		System.out.println("Hangi indisi silmek istiyosunuz?");
		int indis = sc.nextInt();
		
		sayiListe.remove(indis);
		
		for (int i = 0; i < sayiListe.size(); i++) {
			System.out.println(sayiListe.get(i));
		}

	}

}
