import java.util.ArrayList;

public class ArrayList_Ornek1 {

	public static void main(String[] args) {
		
		
		// List, set, map - java collections/generic
		
		// ArrayList
		
		String[] iller= new String[3];
		
		iller[0] = "�stanbul";
		iller[1] = "Ankara";
		iller[2] = "Bursa";
		
		
		for (int i = 0; i < iller.length; i++) {
			System.out.println(iller[i]);
		}
		
		
		
		//t�m elemanlar� tek tek gezme: iteration
		for (String string : iller) {
			System.out.println(string);
		}
		
		//collectionlar� dizilerin daha geli�mi� versiyonu olarak d���nebiliriz
		
		
		ArrayList<String> illerListe = new ArrayList<>();

		illerListe.add("�stanbul");
		illerListe.add("Ankara");
		illerListe.add("Bursa");
		
		
		for (int i = 0; i < illerListe.size(); i++) {
			System.out.println(illerListe.get(i));
		}
		
		
		for (String string : illerListe) {
			System.out.println(string);
		}
		
		/*
		 add() --> listeye eleman ekleemk i�n kullan�l�r
		 clear() --> listedeki t�m elemanlar� silmek i�in kullan�l�r
		 get() --> indisini bildi�imiz eleman� �a��rmak i�in kullan�l�r
		 size() --> listenin eleman say�s�n� d�ner
		 isEmpty() --> liste bo� ise true, doluysa false d�ner
		 remove() --> indisini bildi�imiz eleman� silmek i�in kullan�l�r
		 indexOf() --> ismini bildi�imiz eleman�n ka��nc� s�rada oldu�unu belirtir. ilk buldu�u eleman� i�aret eder
		 lastIndexOf() --> ismini bildi�imiz eleman�n ka��nc� s�rada oldu�unu belirtir. son buldu�u eleman� i�aret eder
		 iterator --> elemanlar� gezmek i�in kullan�l�r
		 toArray() --> list'i diziye �evirmek i�in kullan�l�r
		 equals() --> kar��la�t�rmak i�in kullan�l�r
		 contains() --> i�ermek/ listede bir eleman�n var olup olmad���n� sorgulamaki�in kullan�l�r
		 
		 
 		 */
	}

}
