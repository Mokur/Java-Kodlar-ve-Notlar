import java.util.HashMap;
import java.util.Scanner;

public class Hashmap_Ornek2 {

	public static void main(String[] args) {
		

		//d��ar�dan n adet key ve value iste, a� adet istedi�ini sor, hashmap i�erisinde sakla daha sonra
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ka� adet de�er girmek istiyosunuz:  ");
		int adet = sc.nextInt();
		
		
		HashMap<String,String> degerler = new HashMap<String,String>();
		
		for (int i = 0; i < adet; i++) {
			System.out.println((i+1) +". anahtar� giriniz: ");
			String anahtar = sc.next();
			
			System.out.println((i+1) +". de�eri giriniz: ");
			String deger = sc.next();
			degerler.put(anahtar, deger);
			
			
			
		}
		
		System.out.println("Anahtar giriniz: ");
		String anahtar = sc.next();
		
		if(degerler.containsKey(anahtar)) {
			System.out.println("Anahtara ait de�er: "+degerler.get(anahtar));
		}else {
			System.out.println("Listede arad���n�z anahtar bulunamad�");
		}
	}

}
