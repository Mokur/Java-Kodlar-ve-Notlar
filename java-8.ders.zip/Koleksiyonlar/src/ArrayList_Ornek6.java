import java.util.ArrayList;

public class ArrayList_Ornek6 {

	public static void main(String[] args) {
		
		
		ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
		
		//String ogrenciAdSoyad, int dogumYili, int okulaBaslamaYili, String okul, String bolum, double notOrtalamasi, String email
		
		ogrenciler.add(new Ogrenci(
				"Ad Soyad",
				1990,
				2010,
				"�stanbul �niversitesi",
				"Bilgisayar Programc�l���",
				3.60d,
				"email@gmail.com")
				);
		
		
		
		ogrenciler.add(new Ogrenci(
				"Merve Okur",
				1996,
				2017,
				"Marmara �niversitesi",
				"Bilgisayar Programc�l���",
				3.0d,
				"merveokuur@gmail.com")
				);
		
		
		ogrenciler.add(new Ogrenci(
				"Emre H�z",
				1996,
				2017,
				"Marmara �niversitesi",
				"Bilgisayar Programc�l���",
				2.0d,
				"emrehiz@gmail.com")
				);
		
		
		for (Ogrenci ogrenci : ogrenciler) {
			System.out.println(ogrenci.getOgrenciAdSoyad());
		}
		

	}

}
