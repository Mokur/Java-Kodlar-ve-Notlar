
public class Ogrenci {

	
	private String ogrenciAdSoyad;
	private int dogumYili;
	private int okulaBaslamaYili;
	private String okul;
	private String bolum;
	private double notOrtalamasi;
	private String email;
	
	public Ogrenci() {
		
	}
	
	
	
	
	public Ogrenci(String ogrenciAdSoyad, int dogumYili, int okulaBaslamaYili, String okul, String bolum,
			double notOrtalamasi, String email) {
		super();
		this.ogrenciAdSoyad = ogrenciAdSoyad;
		this.dogumYili = dogumYili;
		this.okulaBaslamaYili = okulaBaslamaYili;
		this.okul = okul;
		this.bolum = bolum;
		this.notOrtalamasi = notOrtalamasi;
		this.email = email;
	}
	
	
	
	@Override
	public String toString() {
		return "Ogrenci [ogrenciAdSoyad=" + ogrenciAdSoyad + ", dogumYili=" + dogumYili + ", okulaBaslamaYili="
				+ okulaBaslamaYili + ", okul=" + okul + ", bolum=" + bolum + ", notOrtalamasi=" + notOrtalamasi
				+ ", email=" + email + "]";
	}




	public String getOgrenciAdSoyad() {
		return ogrenciAdSoyad;
	}
	public void setOgrenciAdSoyad(String ogrenciAdSoyad) {
		this.ogrenciAdSoyad = ogrenciAdSoyad;
	}
	public int getDogumYili() {
		return dogumYili;
	}
	public void setDogumYili(int dogumYili) {
		this.dogumYili = dogumYili;
	}
	public int getOkulaBaslamaYili() {
		return okulaBaslamaYili;
	}
	public void setOkulaBaslamaYili(int okulaBaslamaYili) {
		this.okulaBaslamaYili = okulaBaslamaYili;
	}
	public String getOkul() {
		return okul;
	}
	public void setOkul(String okul) {
		this.okul = okul;
	}
	public String getBolum() {
		return bolum;
	}
	public void setBolum(String bolum) {
		this.bolum = bolum;
	}
	public double getNotOrtalamasi() {
		return notOrtalamasi;
	}
	public void setNotOrtalamasi(double notOrtalamasi) {
		this.notOrtalamasi = notOrtalamasi;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
