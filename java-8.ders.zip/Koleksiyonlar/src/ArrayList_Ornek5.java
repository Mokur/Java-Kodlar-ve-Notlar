import java.util.ArrayList;

public class ArrayList_Ornek5 {

	
	
	public static void meyveGetir(ArrayList<String> meyveListe, char ch) {
		
		for (int i = 0; i < meyveListe.size(); i++) {
			if(meyveListe.get(i).startsWith(""+ch)) {
				System.out.println(meyveListe.get(i));
			}
		}
	}
	
	public static void main(String[] args) {
		////metot �ret d��ar�dan alma main i�inde meyveler string 
		//arraylist meyve isimleri yaz a ile ba�layan b ile ba�layan vs metotda arraylist g�nder harf g�nder ona g�re getirsin  arraylist ve char g�nder
		
		
		ArrayList<String> meyveListe = new ArrayList<>();
	
		
		
		meyveListe.add("Kavun");
		meyveListe.add("Karpuz");
		meyveListe.add("Kiraz");
		meyveListe.add("Kay�s�");
		
		
		meyveListe.add("Ayva");
		meyveListe.add("Armut");
		meyveListe.add("Ahududu");
		
		
		System.out.println("K ile ba�layan meyveler: ");
		meyveGetir(meyveListe,'K');
		
		System.out.println("A ile ba�layan meyveler:");
		meyveGetir(meyveListe,'A');
		
		
		
		
	}

}
