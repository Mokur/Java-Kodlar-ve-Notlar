import java.util.ArrayList;

public class ArrayList_Ornek7 {

	public static void main(String[] args) {
		
		
		ArrayList<Araba> arabalar = new ArrayList<>();
		
		//String marka, String model, int uretimYili, String renk, String vitesTuru
		
		arabalar.add(new Araba("Marka 1","Model 1",2018,"mavi","manuel"));
		arabalar.add(new Araba("Marka 2","Model 2",2018,"k�rm�z�","manuel"));
		arabalar.add(new Araba("Marka3","Model 3",2018,"gri","otomatik"));
		

		
		for (Araba araba : arabalar) {
			System.out.println("Araban�n markas�: "+araba.getMarka());
			System.out.println("Araban�n modeli: "+araba.getModel());
			System.out.println("Araban�n �retim y�l�: "+araba.getUretimYili());
			System.out.println("Araban�n rengi: "+araba.getRenk());
			System.out.println("Araban�n vites t�r�: "+araba.getVitesTuru());
			System.out.println("-------------------------");
			
		}
		
		
		System.out.println(arabalar.get(1).getRenk());
	}

}
