import java.util.LinkedList;

public class LinkedList_Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		LinkedList<String> liste = new LinkedList<>();
		
		
		liste.add("PHP");
		liste.add("Java");
		liste.add("Kotlin");
		liste.add("Javascript");
		liste.add("Objective C");
		liste.addFirst("Python");
		liste.addFirst("Swift");
		
		
		for (String string : liste) {
			System.out.println(string);
		}
		
		System.out.println("�lk s�radaki eleman: " +liste.get(0));
		liste.removeFirst();
		
		System.out.println("�lk s�radaki eleman: " +liste.getFirst());
		System.out.println("Son s�radaki eleman: " +liste.getLast());
		liste.removeLast();
		System.out.println("Son s�radaki eleman: " +liste.getLast());

	}

}
