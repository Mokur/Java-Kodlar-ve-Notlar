import java.util.Enumeration;
import java.util.Vector;

public class Vector_Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vector<String> vector = new Vector<String>();
		
		vector.addElement("Fatih");
		vector.addElement("Bili�im");
		vector.addElement("Okulu");
		System.out.println("Capacity: "+vector.capacity());
		
		Enumeration vectorEnum = vector.elements();
		
		while (vectorEnum.hasMoreElements()) {
			System.out.println(vectorEnum.nextElement());
			
		}
	}

}
