
public class ContainsOrnegi {

	public static void main(String[] args) {
	
		
		//CONTAINS KULLANIMI
		
		String metin = "Bug�n hava �ok so�uk!";
		
		if(metin.contains("so�uk")) {
			
			System.out.println("metinde so�uk kelimesi ge�mektedir");
			
		}else{
			System.out.println("metinde so�uk kelimesi ge�memektedir");
		}
		
		/*
		 * String i�eriisnde bir ifadeyi aray�p varolup olmad���n� kontrol etmek i�in kullan�l�r. B�y�k k���k harf kullan�m� vard�r.
		 */

		
	}

}
