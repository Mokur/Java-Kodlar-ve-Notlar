
public class Ornek9 {

	public static void main(String[] args) {


		//trim metodu
		
		String metin ="  �SMEK Fatih Bili�im Okulu  ";
		String yeniMetin = metin.trim();
		
		System.out.println(metin);
		System.out.println(yeniMetin);
		
	}

}
