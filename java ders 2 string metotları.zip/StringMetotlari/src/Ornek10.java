
public class Ornek10 {

	public static void main(String[] args) {
 
		//Replace kullan�m�
		
		String ders= "Java Dersleri";
		
		String yeniDers= ders.replace("Java", "Android");
		
		System.out.println("ders: "+ders);
		System.out.println("yeni ders: "+yeniDers);
		
		
		if("Java".equals(yeniDers)) {
			System.out.println("ders Java dersidir");
		}else {
			System.out.println("ders art�k java dersi de�ildir");
		}
		
		String yeniHali = yeniDers.replace('A', 'b');
		System.out.println("c�mlenin yeni hali: " +yeniHali);
		
	}

}
