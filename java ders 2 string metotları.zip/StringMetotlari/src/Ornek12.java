
public class Ornek12 {

	public static void main(String[] args) {

		
		//isEmpty kullan�m�
		
		String ifade="";
		
		if(ifade.isEmpty()) {
			System.out.println("ifade bo�tur");
		}else {
			System.out.println("�fade doludur");
		}
	}

}
