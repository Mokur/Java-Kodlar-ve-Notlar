
public class Ornek4 {

	public static void main(String[] args) {
		
		
		String isim1 = "�SMEKB�L���MOKULU";
		String isim2 = "YUNAN�STANBULGAR�STAN";

		// SUBSTR�NG �RNE�� 
		
		System.out.println(isim1.substring(5,12));
		//5. indis dahil 12. indise kadar git. 12 dahil de�il
		
		System.out.println(isim2.substring(5, 13));
		
		
		/*
		 * Substring metodu tek arg�manl� �a��r�rsak, ba�lang�� indisinden stringin sonuna kadar olan k�sm� yazd�r�r
		 */
		
		System.out.println(isim1.substring(5));//5'ten itibaren sonuna kadar yazd�r�r
		
		System.out.println(isim1.substring(0, 5)); // ba�tan be�imnci indise kadar
		
		
	}

}
