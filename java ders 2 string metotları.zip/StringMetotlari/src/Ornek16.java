
public class Ornek16 {

	public static void main(String[] args) {
		//html sayfa i�eirisinde arama yapma �rne�i
		

		StringBuilder sb = new StringBuilder();
		
		sb.append("<html>");
		sb.append("<head></head>");
		sb.append("<body>");
		sb.append("<img src=\"serif.jpg\" />");

		sb.append("</body>");


		sb.append("</html>");
		
		String str = sb.toString();
		String str2 = str.substring(str.indexOf("\"")+1, str.lastIndexOf("\""));
		System.out.println(str2);
		
		

	}

}
