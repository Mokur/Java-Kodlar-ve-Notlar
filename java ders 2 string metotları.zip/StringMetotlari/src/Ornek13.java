
public class Ornek13 {

	public static void main(String[] args) {

		//valueof kullan�m�
		
				int sayi = 100;
				
				String sayi2 = String.valueOf(sayi);
				 System.out.println(sayi2);
				 
				 int sayi3 = Integer.valueOf(sayi2);
				 System.out.println(sayi3);
		
	}

}
