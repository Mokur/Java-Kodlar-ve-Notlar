
public class Ornek15 {

	public static void main(String[] args) {
		// indexOf ve lastIndexOf kullan�m�
		
		String yazi = "Merhaba, ben java ��reniyorum.java dersindeyim";
		
		System.out.println(yazi.indexOf("Java"));
		//ilk ka��nc� indexteyse o indisi d�ner
		
		System.out.println(yazi.lastIndexOf("Java"));
		//en son ka��nc� indexteyse o indisi d�ner
		
		int ilkIndex = yazi.indexOf("Java");
		int sonIndex = yazi.lastIndexOf("Java");
		String araliktakiKelime = yazi.substring(ilkIndex, sonIndex);
		
		System.out.println(araliktakiKelime);

		

	}

}
