
public class Ornek6 {

	public static void main(String[] args) {


		//EQUALS VE EQUALSIGNORECASE KULLANIMI
		
		
		/*
		 * 
		 * Basit veri tiplerinde e�itlik kontrol� == ile sa�lan�r.
		 * String verilerin e�itlik kontrol� i�in stringin equals metodu kullan�l�r
		 */
		String str = "Admin";
		
		if("admin".equals(str)) {
			System.out.println("Ho�geldin!");
			
		}else{
			System.out.println("Hatal� giri�!");
		}
		
		String isim= "�ER�F";
		if("�erif".equalsIgnoreCase(isim)) {
			System.out.println("Ho�geldin patron");
		}else {
			System.out.println("Sizi tan�m�yorum!");
		}
	}

}
