
public class Ornek2 {

	public static void main(String[] args) {


		String email = "conatct@serifgungor.com";
		System.out.println(email.charAt(7));
		
		String sayilar = "123456789";
		System.out.println(sayilar.charAt(5));

		String yazi = "�SMEK";
		System.out.println(yazi.charAt(4));
	}

}
