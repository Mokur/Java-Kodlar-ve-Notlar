
public class Ornek8 {

	public static void main(String[] args) {
		
		//length kullan�m�

		String enUzunKelime="muvaffakiyetsizle�tiricile�tiriveremeyebileceklerimizdenmi�sinizcesine";
		
		System.out.println(enUzunKelime.length());
		
		String okul = "�SMEK Fatih Bili�im Okulu";
		int uzunluk = okul.length();
		System.out.println("Karakter uzunlu�u:" +okul);
				
		
	}

}
