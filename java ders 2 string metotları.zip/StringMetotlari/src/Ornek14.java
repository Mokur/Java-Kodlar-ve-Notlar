
public class Ornek14 {

	public static void main(String[] args) {

		//string format
		
		
		String str = "Merhaba %s %s";
		str = str.format(str, "Java Programlama","Lab09");
		System.out.println(str);
		//%s olan yerlere string gelmeli, ka� tane %s varsa o kadar string yaz�lmal�
	}

}
