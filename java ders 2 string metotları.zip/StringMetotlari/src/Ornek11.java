
public class Ornek11 {

	public static void main(String[] args) {

		
		
		String ifade = "�SMEK FAT�H B�L���M OKULU";
		
		
		String[] dizi = ifade.split(" ") ; 
		System.out.println(dizi[0]);
		System.out.println(dizi[1]);
		System.out.println(dizi[2]);
		System.out.println(dizi[3]);

		
		
	}

}
