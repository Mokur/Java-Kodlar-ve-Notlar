
public class Ornek7 {

	public static void main(String[] args) {

		//startsWith ve EndsWith kullan�malr�
		
		String webSitesi = "www.youtube.com";
		
		
		if(webSitesi.startsWith("www")) {
			System.out.println("Sitenin ba��nda www ifadesi yer al�yor");
		}else {
			System.out.println("Sitenin ba��nda www ifadesi yer alm�yor");
		}
		
		if(webSitesi.endsWith(".com")) {
			System.out.println("Sitenin sonunda .com ifadesi yer al�yor");
		}else {
			System.out.println("Sitenin sonunda .com ifadesi yer alm�yor");
		}
	}

}
