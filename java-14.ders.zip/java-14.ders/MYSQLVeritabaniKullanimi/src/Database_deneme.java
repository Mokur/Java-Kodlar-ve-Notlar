import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Database_deneme {

	
	static Scanner sc;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sc = new Scanner(System.in);
		Database db = new Database();
		db.baglan("otopark", "root", "", "127.0.0.1", 3306);
		int sayi = db.tablodakiVeriSayisi("ucretler");
		//System.out.println(sayi);
		
		
		while (true) {
			System.out.println("L�tfen bir i�lem se�iniz:");
			System.out.println("1 - �cret Tarifelerini Listele");
			System.out.println("2 - Otopark Yerlerini Listele");
			System.out.println("3 - Bir Otoparka Ara� Giri�i Yap");
			System.out.println("4 - Bir Otoparktan Ara� ��k��� Yap");
			System.out.println("5 - Kasadaki Kazanc� G�r");
			System.out.println("6 - Otoparktaki Ara�lar� Listele");
			System.out.println("7 - Otoparktaki Ara� Say�s�n� ��ren");
			System.out.println("8 - Otoparktan ��kan Ara�lar� Listele");


			int islemSayi = sc.nextInt();
			
			
			if (islemSayi==1) {
				
				
				/*
				 ResultSet s�n�f� sayesinde select sorgusundan d�nen t�m sat�r sonu�lar�n� listeleyebiliriz
				 */
				
				ResultSet rs = db.verileriListele("select *from ucretler");
				try {
					
					while (rs.next()) {  //yeni bir sat�r verisi varsa, o verileri de g�rmek i�in kullan�l�r
						int id = rs.getInt("id");
						String saat = rs.getString("saat");
						int fiyat = rs.getInt("fiyat");
						System.out.println("id: " +id);
						System.out.println("saat: " +saat);
						System.out.println("fiyat: " +fiyat);
						System.out.println("--------------");
						
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}else if(islemSayi==2) {
				
				ResultSet rs = db.verileriListele("select * from otopar_yerleri");
				try {
					while (rs.next()) {
						int yer_id = rs.getInt("id");
						String lokasyon_adi = rs.getString("lokasyon_adi");
						int kapasite = rs.getInt("kapasite");
						System.out.println("Yer id: "+yer_id);
						System.out.println("Yer id: "+lokasyon_adi);
						System.out.println("Yer id: "+kapasite);
						
						System.out.println("--------");

						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}else if(islemSayi==3) {
				
				/*
				 insert into araclar(
	    		otopark_yer_id,plaka,otopark_giris_tarihi,
				)values (
	    		1,'34AA1234','16.11.2019'
				)
				 */
				
				System.out.println("L�tfen otopark yer id giriniz: ");
				int yer_id = sc.nextInt();
				System.out.println("L�tfen plaka giriniz: ");
				String plaka = sc.next();
				
				
				
		
				

				db.veriEkle("araclar", "otopark_yer_id,plaka,otopark_giris_tarihi", +yer_id+ ",'" +plaka+ "',now()");
				
				/*
				 * 
				 * db.veriEkle("araclar", 
				 * "otopark_yer_id,plaka,otopark_giris_tarihi", 
						"1,'34AA1234',now()");
				 */
						
				
				
				
			}else if(islemSayi==4) {
				
			}else if(islemSayi==5) {
				
			}else if(islemSayi==6) {
				
			}else if(islemSayi==7) {
				
			}else if(islemSayi==8) {
				
			}else {
				System.out.println("\nHatal� i�lem se�imi, yeniden deneyiniz!\n");
				continue;
			}


			
			

			
		}
		
	}

}
