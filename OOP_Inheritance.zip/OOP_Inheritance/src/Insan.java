


public class Insan extends Adem {

/*	
	public static void konus() {
		System.out.println("�nsan Konu�tu");
	}
*/
}
