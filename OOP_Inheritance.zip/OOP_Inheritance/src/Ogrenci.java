
public class Ogrenci extends Egitim {

	
	public void dersler() {
		System.out.println("��rencinin dersleri");
	}
	
	public void sinifi(int sinif) {
		System.out.println("��rencinin s�n�f�: "+sinif);
	}
}
