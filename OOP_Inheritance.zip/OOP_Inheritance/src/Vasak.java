
public class Vasak extends Kedigil {

	public void yemekYe() {
		System.out.println("Va�ak yemek yedi");
	}
	
	public void vahsiOl() {
		System.out.println("Va�ak vah�i oldu");
	}
	
	
}
