

public class Adem {

 public static void uyu() {
	System.out.println("Adem Uyudu");
}

 public static void yuru() {
	System.out.println("Adem Y�r�d�");
}

 public static void konus() {
	System.out.println("Adem Konu�tu");
}

 public static void yemekYe() {
	System.out.println("Adem Yemek yedi");
}
 

 
 
 

 

}
