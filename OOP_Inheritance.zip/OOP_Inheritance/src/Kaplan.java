
public class Kaplan extends Kedigil {

	
	
	public void vahsiOl() {
		System.out.println("Kaplan vah�i oldu");
	}
	
	
}
