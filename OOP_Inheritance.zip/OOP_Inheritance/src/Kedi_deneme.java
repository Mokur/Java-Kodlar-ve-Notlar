
public class Kedi_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Kedi kedi = new Kedi();
		kedi.sesCikar();
		kedi.kosmaHizi(10);
		kedi.vahsiOl();
		System.out.println("----------------------");
		
		
		Vasak vasak = new Vasak();
		vasak.yemekYe();
		vasak.vahsiOl();
		System.out.println("----------------------");
		
		
		Kaplan kaplan = new Kaplan();
		kaplan.vahsiOl();
		kaplan.sesCikar();
		
		
		

	}

}
