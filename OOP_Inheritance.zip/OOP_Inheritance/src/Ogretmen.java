
public class Ogretmen extends Egitim {

	

	public void dersler() {
		System.out.println("��retmenin dersleri");
	}
	
	public void adSoyad(String adSoyad) {
		System.out.println("��retmenin ad soyad�: "+adSoyad);
	}
	
}
