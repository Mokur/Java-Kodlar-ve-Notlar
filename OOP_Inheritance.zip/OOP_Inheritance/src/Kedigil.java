
public class Kedigil {
	
	public double hiz;
	public boolean vahsiMi;
	
	public void yemekYe() {
		System.out.println("Kedigil yemek yedi");
	}

	public void sesCikar() {
		System.out.println("Kedigil ses ��kard�");
	}
	public void kosmaHizi(double hiz) {
		this.hiz = hiz;
	}
	public void vahsiOl() {
		
			System.out.println("Kedigil vah�i oldu");
		
		
	}
}
