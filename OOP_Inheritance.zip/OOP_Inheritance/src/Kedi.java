
public class Kedi extends Kedigil {

	
	public void yemekYe() {
		System.out.println("Kedi yemek yedi.");
	}
	
	public void sesCikar() {
		super.sesCikar(); // super kelimesi miras al�nan �st s�n�f� temsil eder.
		//super, diyerek �st s�n�ftaki de�i�ken ve metotlara eri�im sa�layabiliriz
		//super();  -  ifadesi �st s�n�f�n bo� constructor'�na denk gelir.
		System.out.println("Kedi miyavlad�.");
	}
	
	public void vahsiOl() {
		System.out.println("Kedi vah�i de�ildir.");
	}
}
