package diziKullanimi;

import java.util.Scanner;

public class Ornek2 {

	
	static Scanner sc;
	public static void main(String[] args) {
		//5 string de�er iste, diziye ata, sonra tek tek yazd�r
		
		sc = new Scanner(System.in);
		
		String strDizi[]= new String[5];
		
		System.out.println("String bir de�er giriniz: " );
		strDizi[0]=sc.next();
		
	
		System.out.println("String bir de�er giriniz: " );
		strDizi[1]=sc.next();
		
		System.out.println("String bir de�er giriniz: " );
		strDizi[2]=sc.next();
		
		System.out.println("String bir de�er giriniz: " );
		strDizi[3]=sc.next();
		
		System.out.println("String bir de�er giriniz: " );
		strDizi[4]=sc.next();
		
		
		System.out.println(strDizi[0]);
		System.out.println(strDizi[1]);
		System.out.println(strDizi[2]);
		System.out.println(strDizi[3]);
		System.out.println(strDizi[4]);


	}

}
